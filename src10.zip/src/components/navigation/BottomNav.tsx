"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, UserRound, Sparkles, Compass, ListChecks, Sparkle } from "lucide-react";

type NavKey = "home" | "you" | "insights" | "explore" | "actions";

type BottomNavProps = {
  activeKey?: NavKey | string;
};

type NavItem = {
  key: NavKey;
  href: string;
  label: string;
  Icon: React.ComponentType<{ className?: string }>;
};

function deriveActiveKey(pathname: string): NavKey | undefined {
  if (pathname === "/main" || pathname.startsWith("/main/home")) return "home";
  if (pathname.startsWith("/main/you")) return "you";
  if (pathname.startsWith("/main/insights")) return "insights";
  if (pathname.startsWith("/main/explore")) return "explore";
  if (pathname.startsWith("/main/actions")) return "actions";
  return undefined;
}

export function BottomNav({ activeKey }: BottomNavProps) {
  const pathname = usePathname();
  const resolvedActiveKey =
    (activeKey as NavKey | undefined) ?? deriveActiveKey(pathname);

  // requested order: home, you, insights, explore, actions
  const items: NavItem[] = [
    { key: "home", href: "/main/home", label: "Home", Icon: Home },
    { key: "you", href: "/main/you", label: "You", Icon: UserRound },
    { key: "insights", href: "/main/insights", label: "Insights", Icon: Sparkles },
    { key: "explore", href: "/main/explore", label: "Explore", Icon: Compass },
    { key: "actions", href: "/main/actions", label: "Actions", Icon: ListChecks },
  ];

  return (
    <nav aria-label="Bottom navigation" className="fixed bottom-0 left-0 right-0 z-50">
      {/* Right-side floating Guide orb (FAB) */}
      <Link
        href="/main/guide"
        aria-label="Guide"
        className={[
          "fixed z-[60]",
          // Right side, slightly inset from the edge
          "right-4",
          // Float just above the footer bar (tuned to your bar height)
          "bottom-[76px]",
          "h-14 w-14 rounded-full",
          "border border-white/20",
          "bg-white/12 backdrop-blur-md",
          "shadow-xl shadow-black/40",
          "grid place-items-center",
          "transition hover:bg-white/16 active:scale-95",
        ].join(" ")}
      >
        <div className="absolute inset-0 rounded-full ring-1 ring-white/10" />
        <Sparkle className="h-6 w-6 text-white" />
      </Link>

      {/* Footer bar (even tabs) */}
      <div className="border-t border-white/10 bg-black/45 backdrop-blur-md">
        <div className="mx-auto flex w-full items-center justify-between px-4 py-2">
          {items.map(({ key, href, label, Icon }) => {
            const active = resolvedActiveKey === key;

            return (
              <Link
                key={key}
                href={href}
                className="flex w-full flex-col items-center justify-center gap-1 rounded-xl px-2 py-2 hover:bg-white/5"
              >
                <Icon className={active ? "h-5 w-5 text-white" : "h-5 w-5 text-white/55"} />
                <span className={active ? "text-[11px] text-white" : "text-[11px] text-white/55"}>
                  {label}
                </span>
              </Link>
            );
          })}
        </div>

        <div className="h-[env(safe-area-inset-bottom)]" />
      </div>
    </nav>
  );
}
