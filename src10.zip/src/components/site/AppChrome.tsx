// src/components/site/AppChrome.tsx
"use client";

import * as React from "react";

import {
  DEFAULT_THEME_ID,
  DEFAULT_GRADIENT_LEVEL,
  getThemeById,
  getGradientConfig,
  getPageBackgroundImage,
  type SpotlightThemeId,
  type GradientLevel,
} from "@/theme/everleapVisuals";

type AppChromeProps = {
  title?: string;
  children: React.ReactNode;

  themeId?: SpotlightThemeId;
  gradientLevel?: GradientLevel;

  className?: string;

  /** Accept legacy/unknown props without breaking pages */
  [key: string]: unknown;
};

export function AppChrome({
  title,
  children,
  themeId = DEFAULT_THEME_ID,
  gradientLevel = DEFAULT_GRADIENT_LEVEL,
  className,
}: AppChromeProps) {
  const theme = getThemeById(themeId);
  const gradient = getGradientConfig(gradientLevel);
  const bgImage = getPageBackgroundImage(themeId, gradientLevel);

  const showHeader = Boolean(title);

  return (
    <div
      className={[
        "min-h-dvh w-full relative overflow-hidden",
        theme.pageBgBaseClass,
        className ?? "",
      ].join(" ")}
      style={
        {
          backgroundImage: bgImage,
        } as React.CSSProperties
      }
    >
      {/* Ambient blobs */}
      {gradient.ambientOpacity > 0 && (
        <>
          <div
            aria-hidden="true"
            className={[
              "pointer-events-none absolute -top-24 -left-24 h-[420px] w-[420px] rounded-full blur-3xl",
              theme.ambientTopLeftClass,
            ].join(" ")}
            style={{ opacity: gradient.ambientOpacity }}
          />
          <div
            aria-hidden="true"
            className={[
              "pointer-events-none absolute -bottom-24 -right-24 h-[480px] w-[480px] rounded-full blur-3xl",
              theme.ambientRightClass,
            ].join(" ")}
            style={{ opacity: gradient.ambientOpacity }}
          />
        </>
      )}

      {/* Header (ONLY when title exists) */}
      {showHeader && (
        <header className="relative z-10 mx-auto w-full max-w-5xl px-4 pt-3">
          <div className="flex items-center justify-between">
            <div className="min-w-0">
              <h1 className="truncate text-lg font-semibold tracking-tight">
                {title}
              </h1>
            </div>

            {/* spacing placeholder (no controls) */}
            <div className="h-10 w-10 opacity-0" aria-hidden="true" />
          </div>
        </header>
      )}

      {/* Content */}
      <main
        className={[
          "relative z-10 mx-auto w-full max-w-5xl px-4 pb-24",
          showHeader ? "pt-3" : "pt-2",
        ].join(" ")}
      >
        {children}
      </main>
    </div>
  );
}
