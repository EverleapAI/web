"use client";

import * as React from "react";
import { useParams, useRouter } from "next/navigation";

import { AppChrome } from "@/components/site/AppChrome";
import { BottomNav } from "@/components/navigation/BottomNav";
import { StepperShell } from "@/components/career/StepperShell";

import {
  type SpotlightThemeId,
  type GradientLevel,
  isDarkTheme,
  INSIGHTS_THEMES,
} from "@/theme/everleapVisuals";

import { getCareerLane } from "@/components/career/lanes";
import type { StepperLaneId } from "@/components/career/stepperTypes";

function normalizeLaneId(raw: string | string[] | undefined): StepperLaneId | null {
  const v = Array.isArray(raw) ? raw[0] : raw;
  if (!v) return null;

  // Support both new ids and your older short ids (optional but handy)
  if (v === "productUx") return "productUx";
  if (v === "healthHumanSupport") return "healthHumanSupport";
  if (v === "educationCommunityPrograms") return "educationCommunityPrograms";
  if (v === "independentBuilder") return "independentBuilder";

  // Back-compat aliases (so /main/career/product still works)
  if (v === "product") return "productUx";
  if (v === "health") return "healthHumanSupport";
  if (v === "social") return "educationCommunityPrograms";
  if (v === "builder") return "independentBuilder";

  return null;
}

export default function CareerLanePage() {
  const params = useParams<{ lane?: string }>();
  const router = useRouter();

  const laneId = normalizeLaneId(params?.lane);
  const lane = laneId ? getCareerLane(laneId) : null;

  // Shared visual state (same pattern you already use)
  const [themeId, setThemeId] = React.useState<SpotlightThemeId>("nightDusk");
  const [gradientLevel, setGradientLevel] = React.useState<GradientLevel>(3);

  const dark = isDarkTheme(themeId);
  const theme = INSIGHTS_THEMES.find((t) => t.id === themeId) ?? INSIGHTS_THEMES[0];

  const cardShadow = dark
    ? "shadow-[0_24px_80px_rgba(0,0,0,0.75)]"
    : "shadow-[0_16px_45px_rgba(0,0,0,0.18)]";

  const surface = `${theme.cardBgClass} ${theme.cardBorderClass} ${cardShadow} backdrop-blur-xl`;

  if (!lane) {
    return (
      <AppChrome
        themeId={themeId}
        setThemeId={setThemeId}
        gradientLevel={gradientLevel}
        setGradientLevel={setGradientLevel}
        orbSource="career_lane_missing"
        ambientCap={0.35}
      >
        <div className="relative flex min-h-[100svh] flex-col">
          <main className="relative z-10 mx-auto flex w-full max-w-2xl flex-1 flex-col px-4 pb-24 pt-6">
            <section className={`rounded-[28px] border px-5 py-5 ${surface}`}>
              <div className="text-sm font-semibold">That lane doesn’t exist yet.</div>
              <p className={`mt-2 text-sm ${dark ? "text-slate-200/85" : "text-slate-700"}`}>
                Go back to Insights and pick a lane again.
              </p>

              <button
                type="button"
                className={`mt-4 inline-flex items-center justify-center rounded-full border px-4 py-2 text-sm font-semibold transition active:scale-95 ${
                  dark
                    ? "border-white/10 bg-white/5 text-slate-100 hover:bg-white/10"
                    : "border-slate-200 bg-white/80 text-slate-800 hover:bg-white"
                }`}
                onClick={() => router.push("/main/carousel")}
              >
                Back to Insights
              </button>
            </section>
          </main>

          <BottomNav />
        </div>
      </AppChrome>
    );
  }

  return (
    <AppChrome
      themeId={themeId}
      setThemeId={setThemeId}
      gradientLevel={gradientLevel}
      setGradientLevel={setGradientLevel}
      orbSource="career_stepper"
      ambientCap={0.35}
    >
      <div className="relative flex min-h-[100svh] flex-col">
        <main className="relative z-10 mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 pb-24 pt-5 md:px-8 md:pt-7">
          <StepperShell lane={lane} surfaceClassName={surface} />
        </main>

        <BottomNav />
      </div>
    </AppChrome>
  );
}
