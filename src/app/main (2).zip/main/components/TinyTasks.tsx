// src/components/TinyTasks.tsx
"use client";

import * as React from "react";

export type TinyTaskId = "weekly_focus" | "curiosity_sprint";

export type TinyTaskSummary = {
  id: TinyTaskId;
  title: string;
  subtitle?: string;
  count?: number; // optional: “1 saved”, etc.
};

export function TinyTasks(props: {
  tasks: TinyTaskSummary[];
  onOpenTask: (id: TinyTaskId) => void;
}) {
  const { tasks, onOpenTask } = props;

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02]">
      <div className="px-4 pt-4 pb-2">
        <div className="text-sm font-semibold tracking-tight">Tiny tasks</div>
        <div className="text-xs text-white/60 mt-0.5">Small moves that build momentum.</div>
      </div>

      <div className="px-2 pb-2">
        {tasks.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => onOpenTask(t.id)}
            className={[
              "w-full text-left",
              "rounded-xl",
              "px-3 py-3",
              "hover:bg-white/[0.04] transition",
              "flex items-center justify-between gap-3",
            ].join(" ")}
          >
            <div>
              <div className="text-sm font-medium text-white/85">{t.title}</div>
              {t.subtitle ? <div className="text-xs text-white/55 mt-0.5">{t.subtitle}</div> : null}
            </div>

            <div className="flex items-center gap-2">
              {typeof t.count === "number" && t.count > 0 ? (
                <div className="text-[11px] text-white/60">{t.count} saved</div>
              ) : null}
              <div className="h-6 w-6 rounded-full border border-white/10 bg-white/[0.03] flex items-center justify-center">
                <span className="text-white/70 text-sm leading-none">›</span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}