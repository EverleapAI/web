// src/app/main/components/SignalsModule.tsx
"use client";

import * as React from "react";
import Link from "next/link";

import type { SignalKey, SignalsProgress } from "../domain/types";
import { hrefForSignal, signalLabel } from "../domain/signals";

export function SignalsModule(props: {
  dark: boolean;
  nextKey: SignalKey;
  progress: SignalsProgress;
}) {
  const { dark, nextKey, progress } = props;

  const totalAnswered =
    progress.motivationsAnswered + progress.strengthsAnswered + progress.skillsAnswered;
  const totalAll = progress.totalPer * 3;

  const border = dark ? "border-white/10" : "border-black/10";
  const textDim = dark ? "text-white/55" : "text-slate-500";
  const textMain = dark ? "text-white/85" : "text-slate-900";

  const track = dark ? "bg-white/10" : "bg-black/10";
  const fillDone = dark ? "bg-emerald-300/80" : "bg-emerald-600/80";

  const lanes: Array<{
    k: SignalKey;
    label: string;
    answered: number;
    done: boolean;
  }> = [
    {
      k: "motivations",
      label: "Motivations",
      answered: progress.motivationsAnswered,
      done: progress.motivationsDone,
    },
    {
      k: "strengths",
      label: "Strengths",
      answered: progress.strengthsAnswered,
      done: progress.strengthsDone,
    },
    {
      k: "skills",
      label: "Skills",
      answered: progress.skillsAnswered,
      done: progress.skillsDone,
    },
  ];

  return (
    <Link
      href={hrefForSignal(nextKey)}
      className={[
        "mt-3 block rounded-2xl border px-4 py-4 transition",
        border,
        dark ? "hover:bg-white/5" : "hover:bg-black/4",
        dark ? "focus:ring-white/20" : "focus:ring-black/15",
        "focus:outline-none focus:ring-2",
      ].join(" ")}
      aria-label="Open Signals"
    >
      <div className="flex items-center justify-between gap-3">
        <div
          className={`text-[0.7rem] font-semibold uppercase tracking-[0.26em] ${
            dark ? "text-white/70" : "text-slate-500"
          }`}
        >
          Signals
        </div>

        <div className="flex items-center gap-2">
          <div className={`text-[11px] font-semibold ${textDim}`}>tap to review</div>
          <div className={`text-xs font-semibold ${textDim}`}>
            {totalAnswered}/{totalAll}
          </div>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-4">
        {lanes.map((l) => {
          const meta = l.done ? "done" : `${l.answered}/${progress.totalPer}`;
          const pct = Math.max(0, Math.min(1, l.answered / progress.totalPer));
          const isNext = l.k === nextKey;

          return (
            <div key={l.k} className="min-w-0">
              <div className="flex items-baseline justify-between gap-2">
                <div className={`truncate text-xs font-semibold ${textMain}`}>{l.label}</div>
                <div className={`text-[11px] font-semibold ${textDim}`}>{meta}</div>
              </div>

              <div className={`mt-2 h-[3px] w-full overflow-hidden rounded-full ${track}`} aria-hidden>
                <div
                  className={`h-full rounded-full ${
                    l.done ? fillDone : dark ? "bg-white/12" : "bg-black/12"
                  }`}
                  style={{ width: `${pct * 100}%` }}
                />
              </div>

              <div className="mt-2 flex items-center gap-1" aria-hidden>
                {Array.from({ length: progress.totalPer }).map((_, i) => {
                  const filled = i < l.answered;

                  const dot =
                    l.done && filled
                      ? dark
                        ? "bg-emerald-300/80"
                        : "bg-emerald-600/80"
                      : filled
                      ? dark
                        ? "bg-white/28"
                        : "bg-slate-900/30"
                      : dark
                      ? "bg-white/10"
                      : "bg-black/10";

                  const opacity = isNext ? "opacity-90" : "opacity-80";

                  return <span key={i} className={`h-1.5 w-1.5 rounded-full ${dot} ${opacity}`} />;
                })}
              </div>
            </div>
          );
        })}
      </div>

      <div className={`mt-3 text-xs ${textDim}`}>
        Next review: <span className={`${dark ? "text-white/75" : "text-slate-800"}`}>
          {signalLabel(nextKey)}
        </span>
      </div>
    </Link>
  );
}