// src/app/main/page.tsx
"use client";

import * as React from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, ChevronDown, ChevronUp } from "lucide-react";

import { BottomNav } from "@/components/navigation/BottomNav";
import { AppChrome } from "@/components/site/AppChrome";

import {
  isDarkTheme,
  type SpotlightThemeId,
  type GradientLevel,
  INSIGHTS_THEMES,
} from "@/theme/everleapVisuals";

// Modal extracted (Step 1)
import {
  TaskRunnerModal,
  type TinyTaskId,
  type OnboardingSnapshot,
  type WeeklyFocusState,
  type CuriositySprintState,
} from "./TaskRunnerModal";

// Reuse onboarding zip helpers (STATE only — no city callouts)
import { lookupZipPlace, stateFullName } from "../onboarding/zipLookup";

/* =============================================================================
   Storage keys (UNCHANGED)
   ============================================================================= */

const ONBOARDING_STORAGE_KEY = "everleapOnboarding_v4_convo_min";
const STORY_STORAGE_KEY = "everleap.story.answers.v3";

const QUOTE_SESSION_KEY = "everleap.main.quote.v1";
const ZIP_PLACE_SESSION_PREFIX = "everleap.zipPlace.v1:";

// Tiny task storage (UI-only for now; Actions hookup later)
const TINY_TASKS_SESSION_KEY = "everleap.main.tiny.session.v1";
const WEEKLY_FOCUS_KEY = "everleap.focus.week.v1";
const CURIOSITY_SPRINTS_KEY = "everleap.sprints.v1";

// Stable “pseudo-AI retort” cache (fingerprint-based)
const RETORT_CACHE_KEY = "everleap.main.retort.cache.v1";

/* =============================================================================
   Types
   ============================================================================= */

type StoryAnswers = Record<string, { answer?: string; skipped?: boolean }>;

type Quote = { text: string; author: string };

type SessionTinyState = {
  shownIds: TinyTaskId[];
  completedIds: TinyTaskId[];
};

type SignalKey = "motivations" | "strengths" | "skills";

type SignalsProgress = {
  motivationsDone: boolean;
  strengthsDone: boolean;
  skillsDone: boolean;
  motivationsAnswered: number;
  strengthsAnswered: number;
  skillsAnswered: number;
  totalPer: number;
};

type AgentState = "EMPTY" | "WELCOME" | "FOUNDATION" | "ACTIVE" | "RETURNING";

type RetortResult = {
  paragraphs: string[]; // 2–3 paragraphs (rendered as narrative)
  fp: string; // fingerprint used for stability
};

type TopicToken =
  | "creative"
  | "analytical"
  | "builder"
  | "helper"
  | "leader"
  | "adventurous"
  | "athletic"
  | "curious"
  | "organized"
  | "expressive";

/* =============================================================================
   Utils
   ============================================================================= */

function safeJsonParse<T>(raw: string | null): T | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function safeJsonStringify(value: unknown) {
  try {
    return JSON.stringify(value);
  } catch {
    return "";
  }
}

function firstName(raw: string) {
  const cleaned = (raw ?? "").trim().replace(/\s+/g, " ");
  if (!cleaned) return "";
  const first = cleaned.split(" ")[0] ?? "";
  return first.replace(/^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$/g, "");
}

function niceName(raw: string) {
  const n = firstName(raw);
  if (!n) return "";
  return n.length === 1 ? n.toUpperCase() : `${n[0]!.toUpperCase()}${n.slice(1)}`;
}

function isAnswered(v: { answer?: string; skipped?: boolean } | undefined) {
  const ans = (v?.answer ?? "").trim();
  const skipped = Boolean(v?.skipped);
  return skipped || ans.length > 0;
}

function countAnsweredForPrefix(answers: StoryAnswers | null, prefix: string, totalPer: number) {
  if (!answers) return 0;
  let n = 0;
  for (let i = 1; i <= totalPer; i += 1) {
    const id = `${prefix}_${i}`;
    if (isAnswered(answers[id])) n += 1;
  }
  return n;
}

function deriveSignalsProgress(answers: StoryAnswers | null): SignalsProgress {
  const totalPer = 5;
  const motivationsAnswered = countAnsweredForPrefix(answers, "motivations", totalPer);
  const strengthsAnswered = countAnsweredForPrefix(answers, "strengths", totalPer);
  const skillsAnswered = countAnsweredForPrefix(answers, "skills", totalPer);

  return {
    motivationsDone: motivationsAnswered >= totalPer,
    strengthsDone: strengthsAnswered >= totalPer,
    skillsDone: skillsAnswered >= totalPer,
    motivationsAnswered,
    strengthsAnswered,
    skillsAnswered,
    totalPer,
  };
}

function nextSignal(progress: SignalsProgress): SignalKey {
  if (!progress.motivationsDone) return "motivations";
  if (!progress.strengthsDone) return "strengths";
  if (!progress.skillsDone) return "skills";
  return "motivations";
}

function signalLabel(k: SignalKey) {
  if (k === "motivations") return "Motivations";
  if (k === "strengths") return "Strengths";
  return "Skills";
}

function hrefForSignal(k: SignalKey) {
  return `/main/questions?cat=${k}&returnTo=/main`;
}

function continueButtonText(k: SignalKey) {
  return `Continue with ${signalLabel(k)}`;
}

function continueSubcopy(k: SignalKey, progress: SignalsProgress) {
  if (k === "motivations") return "2 minutes. First signal. Sets your baseline.";
  if (k === "strengths") {
    const n = progress.strengthsAnswered;
    return n > 0
      ? "2 minutes. Second signal. Sharpens what fits."
      : "2 minutes. Second signal. Finds what you do best.";
  }
  return "2 minutes. Third signal. Turns insight into momentum.";
}

function strengthsWhyLine() {
  return "Your strengths are where you naturally do your best work — so the options I suggest actually match how you operate.";
}

/* =============================================================================
   Quote (stable per session)
   ============================================================================= */

const QUOTES: Quote[] = [
  { text: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe" },
  {
    text: "You don’t have to see the whole staircase. Just take the first step.",
    author: "Martin Luther King Jr.",
  },
  { text: "The future depends on what you do today.", author: "Mahatma Gandhi" },
  { text: "Action is the foundational key to all success.", author: "Pablo Picasso" },
  {
    text: "What you do makes a difference. And you have to decide what kind of difference you want to make.",
    author: "Jane Goodall",
  },
];

function pickStableSessionQuote(): Quote {
  if (typeof window === "undefined") return QUOTES[0]!;
  try {
    const existing = safeJsonParse<Quote>(window.sessionStorage.getItem(QUOTE_SESSION_KEY));
    if (existing?.text && existing?.author) return existing;

    const idx = Math.floor(Math.random() * QUOTES.length);
    const chosen = QUOTES[idx] ?? QUOTES[0]!;
    window.sessionStorage.setItem(QUOTE_SESSION_KEY, JSON.stringify(chosen));
    return chosen;
  } catch {
    return QUOTES[0]!;
  }
}

/* =============================================================================
   Zip -> STATE label (cached per session)
   ============================================================================= */

function zipCacheKey(zip5: string) {
  return `${ZIP_PLACE_SESSION_PREFIX}${zip5}`;
}

async function resolveHomeStateLabel(zip5: string): Promise<string | null> {
  if (!zip5) return null;
  if (typeof window === "undefined") return null;

  try {
    const cached = window.sessionStorage.getItem(zipCacheKey(zip5));
    if (cached) return cached;

    const place = await lookupZipPlace(zip5);
    if (!place) return null;

    // STATE ONLY (no city)
    const label = stateFullName(place.state);
    window.sessionStorage.setItem(zipCacheKey(zip5), label);
    return label;
  } catch {
    return null;
  }
}

/* =============================================================================
   Tiny task state (session + persisted)
   ============================================================================= */

function readSessionTinyState(): SessionTinyState {
  if (typeof window === "undefined") return { shownIds: [], completedIds: [] };

  const parsed = safeJsonParse<SessionTinyState>(
    window.sessionStorage.getItem(TINY_TASKS_SESSION_KEY)
  );
  if (!parsed) return { shownIds: [], completedIds: [] };

  const shownIds = Array.isArray(parsed.shownIds)
    ? (parsed.shownIds.filter(
        (v): v is TinyTaskId => v === "weekly_focus" || v === "curiosity_sprint"
      ) as TinyTaskId[])
    : [];

  const completedIds = Array.isArray(parsed.completedIds)
    ? (parsed.completedIds.filter(
        (v): v is TinyTaskId => v === "weekly_focus" || v === "curiosity_sprint"
      ) as TinyTaskId[])
    : [];

  return { shownIds, completedIds };
}

function writeSessionTinyState(next: SessionTinyState) {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(TINY_TASKS_SESSION_KEY, safeJsonStringify(next));
  } catch {
    // ignore
  }
}

function readWeeklyFocus(): WeeklyFocusState | null {
  if (typeof window === "undefined") return null;
  return safeJsonParse<WeeklyFocusState>(window.localStorage.getItem(WEEKLY_FOCUS_KEY));
}

function readSprints(): CuriositySprintState[] {
  if (typeof window === "undefined") return [];
  const parsed = safeJsonParse<CuriositySprintState[]>(
    window.localStorage.getItem(CURIOSITY_SPRINTS_KEY)
  );
  return Array.isArray(parsed) ? parsed : [];
}

/* =============================================================================
   Agent state
   ============================================================================= */

function deriveAgentState(args: {
  snapshot: OnboardingSnapshot | null;
  progress: SignalsProgress;
  hasAnySignal: boolean;
  hasAnyTiny: boolean;
}): AgentState {
  const { snapshot, progress, hasAnySignal, hasAnyTiny } = args;

  const onboardingDone = Boolean(snapshot?.name || snapshot?.zip || snapshot?.situation);

  if (!onboardingDone && !hasAnySignal) return "EMPTY";
  if (onboardingDone && !hasAnySignal) return "WELCOME";

  const allDone = progress.motivationsDone && progress.strengthsDone && progress.skillsDone;
  if (allDone) return hasAnyTiny ? "RETURNING" : "ACTIVE";

  return "FOUNDATION";
}

/* =============================================================================
   Stable fingerprint + stable retort cache (deterministic, non-parroting)
   ============================================================================= */

function stableStringify(value: unknown): string {
  const seen = new WeakSet<object>();

  const helper = (v: unknown): unknown => {
    if (v === null) return null;
    if (typeof v !== "object") return v;

    const obj = v as Record<string, unknown>;
    if (seen.has(obj)) return "[Circular]";
    seen.add(obj);

    if (Array.isArray(v)) return v.map(helper);

    const keys = Object.keys(obj).sort();
    const out: Record<string, unknown> = {};
    for (const k of keys) out[k] = helper(obj[k]);
    return out;
  };

  return JSON.stringify(helper(value));
}

function hashString(input: string): string {
  // djb2-ish; deterministic seed, not crypto
  let h = 5381;
  for (let i = 0; i < input.length; i++) {
    h = (h * 33) ^ input.charCodeAt(i);
  }
  const u = h >>> 0;
  return u.toString(16).padStart(8, "0");
}

function computeFingerprint(args: {
  snapshot: OnboardingSnapshot | null;
  answers: StoryAnswers | null;
  progress: SignalsProgress;
  weeklyFocus: WeeklyFocusState | null;
  sprintCount: number;
  sessionTiny: SessionTinyState;
}): string {
  const payload = {
    snapshot: args.snapshot ?? null,
    answers: args.answers ?? null,
    progress: args.progress,
    weeklyFocus: args.weeklyFocus ?? null,
    sprintCount: args.sprintCount,
    sessionTiny: args.sessionTiny,
  };
  return hashString(stableStringify(payload));
}

function normalizeText(s: string) {
  return (s ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function extractTopicToken(answers: StoryAnswers | null): TopicToken | undefined {
  if (!answers) return undefined;

  // Only consider answer text (not question ids), and never surface it verbatim.
  const combined = normalizeText(
    Object.keys(answers)
      .map((k) => String(answers[k]?.answer ?? "").trim())
      .filter(Boolean)
      .join(" ")
  );

  if (!combined) return undefined;

  const groups: Array<{ token: TopicToken; keywords: string[] }> = [
    {
      token: "creative",
      keywords: ["art", "design", "draw", "paint", "music", "song", "write", "film", "photo", "creative"],
    },
    { token: "analytical", keywords: ["math", "numbers", "logic", "analyze", "research", "data", "stats"] },
    { token: "builder", keywords: ["build", "make", "code", "app", "engineer", "robot", "project", "ship"] },
    { token: "helper", keywords: ["help", "support", "care", "mentor", "listen", "community", "volunteer"] },
    { token: "leader", keywords: ["lead", "organize", "captain", "coach", "manage", "team"] },
    { token: "adventurous", keywords: ["travel", "adventure", "explore", "outdoors", "hike", "camp"] },
    { token: "athletic", keywords: ["sport", "soccer", "basketball", "run", "gym", "fencing", "swim"] },
    { token: "curious", keywords: ["curious", "learn", "discover", "why", "how", "question"] },
    { token: "organized", keywords: ["plan", "schedule", "systems", "checklist", "routine", "organize"] },
    { token: "expressive", keywords: ["express", "feel", "story", "journal", "poem", "voice"] },
  ];

  let best: { token: TopicToken; score: number } | null = null;
  for (const g of groups) {
    let score = 0;
    for (const kw of g.keywords) {
      const k = normalizeText(kw);
      if (combined.includes(k)) score += 1;
    }
    if (score > 0 && (!best || score > best.score)) best = { token: g.token, score };
  }

  return best?.token;
}

function pickBySeed<T>(items: T[], seedHex: string): T {
  if (items.length === 1) return items[0];
  const seed = (parseInt(seedHex.slice(0, 8), 16) >>> 0) || 0;
  return items[seed % items.length]!;
}

function tokenGroundingLine(token?: TopicToken, fp?: string): string | null {
  if (!token) return null;
  const seed = fp ?? "00000000";

  const lines: Record<TopicToken, string[]> = {
    creative: [
      "There’s a creative thread running through how you think — it’s worth building around.",
      "You’ve got a creative signal in the mix — let’s keep it in the room as we pick next steps.",
    ],
    analytical: [
      "You’ve got an analytical signal — you’ll do best with choices that let you test and refine.",
      "There’s a pattern-spotter vibe here — we’ll use it to make cleaner decisions.",
    ],
    builder: [
      "You’ve got a builder signal — you’ll feel best when there’s something real to make.",
      "There’s a “make it real” energy here — we’ll lean into that.",
    ],
    helper: [
      "There’s a helper signal — you’ll get momentum when what you do matters to someone.",
      "You’re wired for impact — we’ll keep that as a north star.",
    ],
    leader: [
      "There’s leadership signal — you’ll thrive where you can set direction and rally people.",
      "You’ve got “organize the chaos” energy — that’s a real asset.",
    ],
    adventurous: [
      "There’s an adventurous signal — you’ll do better with options that widen your world.",
      "You’ve got an explorer vibe — we’ll keep room for bold moves.",
    ],
    athletic: [
      "There’s an athletic signal — consistency + challenge will work unusually well for you.",
      "You’ve got a competitive edge — we’ll use it without letting it run you.",
    ],
    curious: [
      "Curiosity is doing work here — we’ll keep feeding it with the right experiments.",
      "You’ve got a “follow the thread” instinct — that’s how good paths show up.",
    ],
    organized: [
      "You’ve got an organized signal — small systems will multiply your results.",
      "Structure helps you win — we’ll make it light, not rigid.",
    ],
    expressive: [
      "There’s an expressive signal — clarity tends to show up when you put things into words.",
      "You’re tuned to meaning — we’ll keep the work personal, not generic.",
    ],
  };

  return pickBySeed(lines[token], seed);
}

function buildWhyLines(nextKey: SignalKey): string[] {
  if (nextKey === "motivations") {
    return [
      "Motivations comes first because it tells us what genuinely pulls you forward (and what quietly drains you).",
      "Once we have that, the rest of Everleap stops being guesswork — it becomes fit.",
    ];
  }
  if (nextKey === "strengths") {
    return [
      "Strengths is next because it’s how we translate your interests into options that actually match how you operate.",
      "It’s the fastest way to avoid “cool on paper, painful in real life.”",
    ];
  }
  return [
    "Skills is next because it turns the fog into something you can practice and stack.",
    "Once we know what’s already in your toolkit, the next experiments get way more efficient.",
  ];
}

type RetortCache = { fp: string; paragraphs: string[]; updatedAt: number };

function readRetortCache(): RetortCache | null {
  if (typeof window === "undefined") return null;
  return safeJsonParse<RetortCache>(window.localStorage.getItem(RETORT_CACHE_KEY));
}

function writeRetortCache(fp: string, paragraphs: string[]) {
  if (typeof window === "undefined") return;
  const payload: RetortCache = { fp, paragraphs, updatedAt: Date.now() };
  try {
    window.localStorage.setItem(RETORT_CACHE_KEY, safeJsonStringify(payload));
  } catch {
    // ignore
  }
}

function generateRetort(args: {
  fp: string;
  agentState: AgentState;
  nextKey: SignalKey;
  homeState: string | null;
  topic?: TopicToken;
  weeklyFocus: WeeklyFocusState | null;
  sprintCount: number;
  sprintDoneThisSession: boolean;
  progress: SignalsProgress;
}): RetortResult {
  const {
    fp,
    agentState,
    nextKey,
    homeState,
    topic,
    weeklyFocus,
    sprintCount,
    sprintDoneThisSession,
    progress,
  } = args;

  const stateTag = homeState ? ` in ${homeState}` : "";
  const opener = pickBySeed(
    [
      `Here’s what I’m noticing${stateTag}.`,
      `Quick read${stateTag}:`,
      `My take${stateTag}:`,
    ],
    fp
  );

  const bridge = pickBySeed(
    [
      "Let’s keep it simple: one move that makes everything else easier.",
      "I’m going to keep this practical: one good next step, then we expand.",
      "We’ll take the shortest path to clarity, then iterate.",
    ],
    fp.slice(2) + fp
  );

  const grounding = tokenGroundingLine(topic, fp);

  const why = buildWhyLines(nextKey);

  const hasFocus = Boolean(weeklyFocus?.vibe && weeklyFocus?.target);
  const tinyLine = (() => {
    if (agentState === "EMPTY") return null;

    if (sprintDoneThisSession && sprintCount > 0) {
      return "Nice — you already logged a sprint. That’s exactly how this gets real.";
    }

    if (hasFocus) {
      return "I’m also tracking a Weekly Focus you saved — we can build from that anytime.";
    }

    if (sprintCount > 0) {
      return `You’ve got ${sprintCount} sprint${sprintCount === 1 ? "" : "s"} saved — we can pull one up whenever you want.`;
    }

    return "If you want momentum fast, we can spin up a tiny weekly focus after the next step.";
  })();

  // Agent-state specific first paragraph (still deterministic + non-generic, no quoting)
  const stateSpecific = (() => {
    if (agentState === "EMPTY") {
      return [
        "Welcome to Everleap.",
        "We’ll take this one step at a time. I’m not here to test you or push you into a path — I’m here to listen, notice patterns, and help you make sense of options without the noise.",
        "If you’re up for it, we’ll start with Motivations. A few quick prompts are enough for me to get oriented, and then I’ll guide you from there.",
      ];
    }

    if (agentState === "WELCOME") {
      return [
        `${opener} ${bridge}${grounding ? ` ${grounding}` : ""}`,
        `${why[0]} ${why[1]}`,
        tinyLine ? tinyLine : "",
      ].filter(Boolean);
    }

    // FOUNDATION / ACTIVE / RETURNING
    const motivationsCaptured = progress.motivationsDone;
    const strengthsNext = nextKey === "strengths" && !progress.strengthsDone;

    if (strengthsNext && motivationsCaptured) {
      return [
        `${opener} To go from “interesting” to “accurate,” I’d do Strengths next.${grounding ? ` ${grounding}` : ""}`,
        "It helps me understand how you operate day-to-day, so the options I suggest start fitting you instead of a generic profile.",
        tinyLine ? tinyLine : "",
      ].filter(Boolean);
    }

    if (agentState === "RETURNING") {
      return [
        `${opener} You’ve already built momentum — now it’s about tightening the fit.${grounding ? ` ${grounding}` : ""}`,
        "Fewer random ideas, more “that’s exactly my lane.” If you want impact today: refresh one signal, or do one tiny task.",
        tinyLine ? tinyLine : "",
      ].filter(Boolean);
    }

    if (agentState === "ACTIVE") {
      return [
        `${opener} At this point, the game changes: we stop collecting basics and start using them.${grounding ? ` ${grounding}` : ""}`,
        "Turn what we’ve learned into experiments you can actually run this week. Weekly Focus is the simplest start; a Curiosity Sprint is the punchiest.",
        tinyLine ? tinyLine : "",
      ].filter(Boolean);
    }

    // FOUNDATION fallback
    return [
      `${opener} ${bridge}${grounding ? ` ${grounding}` : ""}`,
      `${why[0]} ${why[1]}`,
      tinyLine ? tinyLine : "",
    ].filter(Boolean);
  })();

  return { fp, paragraphs: stateSpecific.slice(0, 3) };
}

function getStableRetort(args: {
  agentState: AgentState;
  nextKey: SignalKey;
  progress: SignalsProgress;
  snapshot: OnboardingSnapshot | null;
  answers: StoryAnswers | null;
  homeState: string | null;
  weeklyFocus: WeeklyFocusState | null;
  sprintCount: number;
  sessionTiny: SessionTinyState;
}): RetortResult {
  const fp = computeFingerprint(args);
  const cached = readRetortCache();
  if (cached && cached.fp === fp && Array.isArray(cached.paragraphs) && cached.paragraphs.length) {
    return { fp, paragraphs: cached.paragraphs.slice(0, 3) };
  }

  const topic = extractTopicToken(args.answers);
  const sprintDoneThisSession = args.sessionTiny.completedIds.includes("curiosity_sprint");

  const next = generateRetort({
    fp,
    agentState: args.agentState,
    nextKey: args.nextKey,
    homeState: args.homeState,
    topic,
    weeklyFocus: args.weeklyFocus,
    sprintCount: args.sprintCount,
    sprintDoneThisSession,
    progress: args.progress,
  });

  writeRetortCache(fp, next.paragraphs);
  return next;
}

/* =============================================================================
   UI bits (sleek Signals module + click affordance)
   ============================================================================= */

function SignalsModule({
  dark,
  progress,
  nextKey,
}: {
  dark: boolean;
  progress: SignalsProgress;
  nextKey: SignalKey;
}) {
  const totalAnswered =
    progress.motivationsAnswered + progress.strengthsAnswered + progress.skillsAnswered;
  const totalAll = progress.totalPer * 3;

  const border = dark ? "border-white/10" : "border-black/10";
  const textDim = dark ? "text-white/55" : "text-slate-500";
  const textMain = dark ? "text-white/85" : "text-slate-900";

  const track = dark ? "bg-white/10" : "bg-black/10";
  const fillDone = dark ? "bg-emerald-300/80" : "bg-emerald-600/80";

  const lanes: Array<{
    k: SignalKey;
    label: string;
    answered: number;
    done: boolean;
  }> = [
    {
      k: "motivations",
      label: "Motivations",
      answered: progress.motivationsAnswered,
      done: progress.motivationsDone,
    },
    {
      k: "strengths",
      label: "Strengths",
      answered: progress.strengthsAnswered,
      done: progress.strengthsDone,
    },
    {
      k: "skills",
      label: "Skills",
      answered: progress.skillsAnswered,
      done: progress.skillsDone,
    },
  ];

  return (
    <Link
      href={hrefForSignal(nextKey)}
      className={[
        "mt-3 block rounded-2xl border px-4 py-4 transition",
        border,
        dark ? "hover:bg-white/5" : "hover:bg-black/4",
        dark ? "focus:ring-white/20" : "focus:ring-black/15",
        "focus:outline-none focus:ring-2",
      ].join(" ")}
      aria-label="Open Signals"
    >
      <div className="flex items-center justify-between gap-3">
        <div
          className={`text-[0.7rem] font-semibold uppercase tracking-[0.26em] ${
            dark ? "text-white/70" : "text-slate-500"
          }`}
        >
          Signals
        </div>

        <div className="flex items-center gap-2">
          <div className={`text-[11px] font-semibold ${textDim}`}>tap to review</div>
          <div className={`text-xs font-semibold ${textDim}`}>
            {totalAnswered}/{totalAll}
          </div>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-4">
        {lanes.map((l) => {
          const meta = l.done ? "done" : `${l.answered}/${progress.totalPer}`;
          const pct = Math.max(0, Math.min(1, l.answered / progress.totalPer));
          const isNext = l.k === nextKey;

          return (
            <div key={l.k} className="min-w-0">
              <div className="flex items-baseline justify-between gap-2">
                <div className={`truncate text-xs font-semibold ${textMain}`}>{l.label}</div>
                <div className={`text-[11px] font-semibold ${textDim}`}>{meta}</div>
              </div>

              <div
                className={`mt-2 h-[3px] w-full overflow-hidden rounded-full ${track}`}
                aria-hidden
              >
                <div
                  className={`h-full rounded-full ${
                    l.done ? fillDone : dark ? "bg-white/12" : "bg-black/12"
                  }`}
                  style={{ width: `${pct * 100}%` }}
                />
              </div>

              <div className="mt-2 flex items-center gap-1" aria-hidden>
                {Array.from({ length: progress.totalPer }).map((_, i) => {
                  const filled = i < l.answered;

                  const dot =
                    l.done && filled
                      ? dark
                        ? "bg-emerald-300/80"
                        : "bg-emerald-600/80"
                      : filled
                      ? dark
                        ? "bg-white/28"
                        : "bg-slate-900/30"
                      : dark
                      ? "bg-white/10"
                      : "bg-black/10";

                  const opacity = isNext ? "opacity-90" : "opacity-80";

                  return <span key={i} className={`h-1.5 w-1.5 rounded-full ${dot} ${opacity}`} />;
                })}
              </div>
            </div>
          );
        })}
      </div>
    </Link>
  );
}

function SectionDivider({ dark }: { dark: boolean }) {
  const line = dark ? "bg-white/10" : "bg-black/10";
  const dot = dark ? "bg-white/25" : "bg-black/20";
  return (
    <div className="py-2" aria-hidden>
      <div className="flex items-center gap-3">
        <div className={`h-px flex-1 ${line}`} />
        <div className={`h-1.5 w-1.5 rounded-full ${dot}`} />
        <div className={`h-px flex-1 ${line}`} />
      </div>
    </div>
  );
}

/* =============================================================================
   Page
   ============================================================================= */

export default function MainHomePage() {
  const [themeId, setThemeId] = React.useState<SpotlightThemeId>("nightDusk");
  const [gradientLevel, setGradientLevel] = React.useState<GradientLevel>(3);

  const dark = isDarkTheme(themeId);
  const theme = INSIGHTS_THEMES.find((t) => t.id === themeId) ?? INSIGHTS_THEMES[0];

  const orbGlowClass =
    "orbGlowClass" in (theme as unknown as Record<string, unknown>)
      ? String((theme as unknown as { orbGlowClass?: string }).orbGlowClass ?? "")
      : dark
      ? "bg-sky-400/25"
      : "bg-amber-300/30";

  const [presenceSoft, setPresenceSoft] = React.useState(false);

  const [snapshot, setSnapshot] = React.useState<OnboardingSnapshot | null>(null);
  const [answers, setAnswers] = React.useState<StoryAnswers | null>(null);
  const [homeState, setHomeState] = React.useState<string | null>(null);

  const [quote, setQuote] = React.useState<Quote>(() => QUOTES[0]!);

  const [taskOpen, setTaskOpen] = React.useState(false);
  const [activeTaskId, setActiveTaskId] = React.useState<TinyTaskId | null>(null);

  const [sessionTiny, setSessionTiny] = React.useState<SessionTinyState>({
    shownIds: [],
    completedIds: [],
  });

  const [weeklyFocus, setWeeklyFocus] = React.useState<WeeklyFocusState | null>(null);
  const [sprintCount, setSprintCount] = React.useState(0);

  const [howWorkOpen, setHowWorkOpen] = React.useState(false);

  React.useEffect(() => {
    const snap = safeJsonParse<OnboardingSnapshot>(
      window.localStorage.getItem(ONBOARDING_STORAGE_KEY)
    );
    const a = safeJsonParse<StoryAnswers>(window.localStorage.getItem(STORY_STORAGE_KEY));

    setSnapshot(snap);
    setAnswers(a);
    setQuote(pickStableSessionQuote());
    setSessionTiny(readSessionTinyState());

    setWeeklyFocus(readWeeklyFocus());
    setSprintCount(readSprints().length);

    const zip5 = (snap?.zip ?? "").trim();
    if (zip5) {
      void (async () => {
        const label = await resolveHomeStateLabel(zip5);
        setHomeState(label);
      })();
    } else {
      setHomeState(null);
    }

    const onFocus = () => {
      const nextSnap = safeJsonParse<OnboardingSnapshot>(
        window.localStorage.getItem(ONBOARDING_STORAGE_KEY)
      );
      const nextAnswers = safeJsonParse<StoryAnswers>(
        window.localStorage.getItem(STORY_STORAGE_KEY)
      );

      setSnapshot(nextSnap);
      setAnswers(nextAnswers);
      setSessionTiny(readSessionTinyState());

      setWeeklyFocus(readWeeklyFocus());
      setSprintCount(readSprints().length);

      const z = (nextSnap?.zip ?? "").trim();
      if (!z) {
        setHomeState(null);
        return;
      }
      void (async () => {
        const label = await resolveHomeStateLabel(z);
        setHomeState(label);
      })();
    };

    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, []);

  React.useEffect(() => {
    const onScroll = () => {
      if (window.scrollY > 8) setPresenceSoft(true);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const name = niceName(snapshot?.name ?? "");

  const progress = deriveSignalsProgress(answers);
  const next = nextSignal(progress);

  const totalAnswered =
    progress.motivationsAnswered + progress.strengthsAnswered + progress.skillsAnswered;

  const hasAnySignal = totalAnswered > 0;
  const hasAnyTiny = Boolean((weeklyFocus?.vibe && weeklyFocus?.target) || sprintCount > 0);

  const agentState = deriveAgentState({ snapshot, progress, hasAnySignal, hasAnyTiny });

  const openTask = (id: TinyTaskId) => {
    const s = readSessionTinyState();
    const shownIds: TinyTaskId[] = Array.from(new Set<TinyTaskId>([...(s.shownIds ?? []), id]));
    const nextState: SessionTinyState = { shownIds, completedIds: s.completedIds ?? [] };
    writeSessionTinyState(nextState);
    setSessionTiny(nextState);

    setActiveTaskId(id);
    setTaskOpen(true);
  };

  const closeTask = () => {
    setTaskOpen(false);
    setActiveTaskId(null);

    setSessionTiny(readSessionTinyState());
    setWeeklyFocus(readWeeklyFocus());
    setSprintCount(readSprints().length);
  };

  const retort = getStableRetort({
    agentState,
    nextKey: next,
    progress,
    snapshot,
    answers,
    homeState,
    weeklyFocus,
    sprintCount,
    sessionTiny,
  });

  const textMuted = dark ? "text-slate-300/85" : "text-slate-700";
  const textFaint = dark ? "text-slate-400" : "text-slate-500";

  // Bottom sections: borderless / list-like
  const taskRowSurface = "bg-transparent";
  const taskRowHover = dark ? "hover:bg-white/5" : "hover:bg-black/4";

  const taskPill = (state: "start" | "set" | "done") => {
    const base = `rounded-full px-3 py-1 text-xs font-semibold border ${
      dark ? "border-white/12" : "border-black/12"
    } bg-transparent`;
    if (state === "done" || state === "set") {
      return `${base} ${dark ? "text-white/70" : "text-slate-700"}`;
    }
    return `${base} ${dark ? "text-white/55" : "text-slate-600"}`;
  };

  const howWorkTitle = "How does Everleap work?";

  const howWorkRowHover = dark ? "hover:bg-white/5" : "hover:bg-black/4";
  const howWorkPillBorder = dark ? "border-white/12" : "border-black/12";
  const howWorkPillText = dark ? "text-white/60" : "text-slate-600";

  const sprintDoneThisSession = sessionTiny.completedIds.includes("curiosity_sprint");

  return (
    <AppChrome
      themeId={themeId}
      setThemeId={setThemeId}
      gradientLevel={gradientLevel}
      setGradientLevel={setGradientLevel}
      orbSource="spotlight_orb"
      ambientCap={0.35}
    >
      <AnimatePresence>
        {taskOpen && activeTaskId ? (
          <TaskRunnerModal
            open={taskOpen}
            onClose={closeTask}
            taskId={activeTaskId}
            snapshot={snapshot}
            dark={dark}
          />
        ) : null}
      </AnimatePresence>

      <div className="relative flex min-h-[100svh] flex-col">
        <main className="relative z-10 mx-auto w-full max-w-3xl flex-1 px-4 pb-24 pt-6 md:px-8 md:pt-8">
          <section className="relative">
            {/* subtle agent presence */}
            <motion.div
              aria-hidden
              className="pointer-events-none absolute -left-1 top-2 h-10 w-10 rounded-full"
              initial={{ opacity: 0 }}
              animate={{ opacity: presenceSoft ? 0.08 : 0.22 }}
              transition={{ duration: 0.6 }}
            >
              <motion.div
                className={`h-full w-full rounded-full ${orbGlowClass} blur-[1px]`}
                animate={{ scale: [1, 1.06, 1] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              />
            </motion.div>

            <div className="pl-12">
              {/* TODAY marker */}
              <div className="mb-3 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.22em] opacity-85">
                <span
                  className={`inline-flex h-5 w-5 items-center justify-center rounded-full text-[0.7rem] ${
                    dark ? "bg-amber-200/90 text-slate-950" : "bg-amber-400 text-slate-900"
                  }`}
                >
                  <Sparkles className="h-3 w-3" />
                </span>
                <span>Today</span>
              </div>

              <div className="space-y-5">
                {/* Quote */}
                <div className={`text-sm ${textFaint}`}>
                  <span className="opacity-80">“</span>
                  <span className="italic">{quote.text}</span>
                  <span className="opacity-80">”</span>
                  <span className="ml-2 opacity-70">— {quote.author}</span>
                </div>

                {/* Greeting + retort */}
                <div>
                  <div className="text-xl font-semibold sm:text-2xl">
                    {name ? `Hey ${name}.` : "Hey."}
                  </div>

                  <div className={`mt-3 space-y-3 text-sm leading-relaxed ${textMuted}`}>
                    {retort.paragraphs.slice(0, 3).map((p, idx) => (
                      <p key={`${retort.fp}_${idx}`}>{p}</p>
                    ))}
                  </div>

                  <SectionDivider dark={dark} />
                </div>

                {/* Next up (BEFORE Signals) */}
                <div>
                  <div className={`text-sm ${dark ? "text-white/70" : "text-slate-600"}`}>
                    Next up:{" "}
                    <span className={`font-semibold ${dark ? "text-white/90" : "text-slate-900"}`}>
                      {signalLabel(next)}
                    </span>
                    .
                  </div>

                  {next === "strengths" ? (
                    <div className={`mt-2 text-sm leading-relaxed ${textMuted}`}>
                      {strengthsWhyLine()}
                    </div>
                  ) : null}

                  <div className="mt-3 flex items-center gap-3">
                    <Link
                      href={hrefForSignal(next)}
                      onClick={() => setPresenceSoft(true)}
                      className={`inline-flex items-center justify-center rounded-full px-4 py-2 text-sm font-semibold transition active:scale-[0.99] ${
                        dark
                          ? "bg-white/10 text-white hover:bg-white/14"
                          : "bg-slate-900 text-white hover:bg-slate-950"
                      }`}
                    >
                      {continueButtonText(next)}
                    </Link>
                  </div>

                  <div className={`mt-2 text-xs ${dark ? "text-white/50" : "text-slate-500"}`}>
                    {continueSubcopy(next, progress)}
                  </div>
                </div>

                {/* Signals (sleek / minimal, now clearly clickable) */}
                <SignalsModule dark={dark} progress={progress} nextKey={next} />

                {/* How does Everleap work? (borderless row) */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => setHowWorkOpen((v) => !v)}
                    className={`group flex w-full items-center justify-between gap-3 rounded-2xl px-2 py-3 text-left transition ${howWorkRowHover} focus:outline-none focus:ring-2 ${
                      dark ? "focus:ring-white/20" : "focus:ring-black/15"
                    }`}
                    aria-expanded={howWorkOpen}
                  >
                    <span
                      className={`min-w-0 text-sm font-semibold leading-relaxed ${
                        dark ? "text-white/85" : "text-slate-900"
                      } group-hover:underline`}
                    >
                      {howWorkTitle}
                    </span>

                    <span
                      className={`shrink-0 inline-flex items-center gap-2 rounded-full border ${howWorkPillBorder} px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] ${howWorkPillText}`}
                    >
                      {howWorkOpen ? "less" : "learn more"}
                      {howWorkOpen ? (
                        <ChevronUp className="h-4 w-4 opacity-70 group-hover:opacity-90" />
                      ) : (
                        <ChevronDown className="h-4 w-4 opacity-70 group-hover:opacity-90" />
                      )}
                    </span>
                  </button>

                  {howWorkOpen ? (
                    <div className={`mt-3 space-y-3 text-sm leading-relaxed ${textMuted}`}>
                      <p>
                        Everleap learns from what you answer, what you explore, and what you actually
                        do — then uses that to choose better next steps.
                      </p>
                      <p>
                        <span className="font-semibold">Signals</span> are your starter baseline
                        (Motivations → Strengths → Skills). Over time, that baseline expands as you
                        use the app, so your “next up” shifts based on what you’ve done recently.
                      </p>
                    </div>
                  ) : null}
                </div>

                {/* Tiny Tasks (borderless list items) */}
                <div className="pt-2">
                  <div
                    className={`text-[0.7rem] font-semibold uppercase tracking-[0.26em] ${
                      dark ? "text-white/70" : "text-slate-500"
                    }`}
                  >
                    Tiny tasks
                  </div>

                  <div className="mt-2 grid gap-1">
                    {/* Weekly Focus */}
                    <button
                      type="button"
                      onClick={() => openTask("weekly_focus")}
                      className={`w-full rounded-2xl ${taskRowSurface} px-2 py-3 text-left transition ${taskRowHover}`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div
                            className={`text-sm font-semibold ${dark ? "text-white/90" : "text-slate-900"}`}
                          >
                            Weekly focus
                          </div>
                          <div className={`mt-1 text-xs ${textFaint}`}>
                            Pick a vibe + a target for this week.
                          </div>
                        </div>

                        {weeklyFocus?.vibe && weeklyFocus?.target ? (
                          <div className={taskPill("set")}>set</div>
                        ) : (
                          <div className={taskPill("start")}>start</div>
                        )}
                      </div>
                    </button>

                    {/* subtle divider between items (no boxes) */}
                    <div
                      className={`mx-2 h-px ${dark ? "bg-white/8" : "bg-black/8"}`}
                      aria-hidden
                    />

                    {/* Curiosity Sprint */}
                    <button
                      type="button"
                      onClick={() => openTask("curiosity_sprint")}
                      disabled={sprintDoneThisSession}
                      className={`w-full rounded-2xl ${taskRowSurface} px-2 py-3 text-left transition ${
                        sprintDoneThisSession
                          ? dark
                            ? "opacity-60"
                            : "opacity-70"
                          : taskRowHover
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div
                            className={`text-sm font-semibold ${dark ? "text-white/90" : "text-slate-900"}`}
                          >
                            Curiosity sprint
                          </div>
                          <div className={`mt-1 text-xs ${textFaint}`}>
                            10 minutes. One small experiment you can actually do.
                          </div>
                          {sprintCount > 0 ? (
                            <div className={`mt-2 text-xs ${textFaint}`}>{sprintCount} saved</div>
                          ) : null}
                        </div>

                        {sprintDoneThisSession ? (
                          <div className={taskPill("done")}>done</div>
                        ) : (
                          <div className={taskPill("start")}>start</div>
                        )}
                      </div>
                    </button>
                  </div>
                </div>

                {/* Footer spacing */}
                <div className="h-3" />
              </div>
            </div>
          </section>
        </main>

        <BottomNav />
      </div>
    </AppChrome>
  );
}