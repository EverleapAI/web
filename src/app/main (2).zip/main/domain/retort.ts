// src/app/main/domain/retort.ts

/* =============================================================================
   Retort assembly (pure, no storage, no React)
   - Uses motivation synthesis to avoid generic copy
   - Enforces deterministic Strengths justification when appropriate
   ============================================================================= */

import type {
  AgentState,
  RetortViewModel,
  SignalKey,
  SignalsProgress,
  OnboardingSnapshot,
  StoryAnswers,
  WeeklyFocusState,
  Reflection,
} from "./types";
import { synthesizeMotivationReflection } from "./motivationSynthesis";

/* ---------------------------------------------------------------------------
   Helpers
--------------------------------------------------------------------------- */

function normalizeSpace(s: string) {
  return (s ?? "").trim().replace(/\s+/g, " ");
}

function firstName(raw: string) {
  const cleaned = (raw ?? "").trim().replace(/\s+/g, " ");
  if (!cleaned) return "";
  const first = cleaned.split(" ")[0] ?? "";
  return first.replace(/^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$/g, "");
}

function niceName(raw: string) {
  const n = firstName(raw);
  if (!n) return "";
  return n.length === 1 ? n.toUpperCase() : `${n[0]!.toUpperCase()}${n.slice(1)}`;
}

function safeOneSentence(s: string) {
  const cleaned = normalizeSpace(s);
  if (!cleaned) return "";
  const m = cleaned.match(/^(.+?[.!?])(\s|$)/);
  return m?.[1] ? m[1].trim() : cleaned;
}

/**
 * Pull a simple “stage” line (high school / college) when we can, without parroting.
 */
function stageLine(snapshot: OnboardingSnapshot | null, rawTextLower: string) {
  const stage =
    typeof snapshot?.stage === "string" ? normalizeSpace(snapshot.stage).toLowerCase() : "";
  const grade =
    typeof snapshot?.grade === "string" ? normalizeSpace(snapshot.grade).toLowerCase() : "";

  const hasAny = (ws: string[]) => ws.some((w) => rawTextLower.includes(w));

  if (stage.includes("high")) return "You’re in high school.";
  if (grade && hasAny(["9", "10", "11", "12", "freshman", "sophomore", "junior", "senior"])) {
    return "You’re in high school.";
  }
  if (hasAny(["high school", "hs", "junior", "senior", "freshman", "sophomore"])) {
    return "You’re in high school.";
  }
  if (hasAny(["community college", "two-year", "college", "university"])) {
    return "You’re thinking about college options.";
  }
  return "";
}

function buildRawText(snapshot: OnboardingSnapshot | null, answers: StoryAnswers | null) {
  // NOTE: we only use this for coarse keyword checks (stageLine). We never surface it.
  const snap = snapshot ? JSON.stringify(snapshot) : "";
  const ans = answers ? JSON.stringify(answers) : "";
  return `${snap}\n${ans}`.toLowerCase();
}

/* ---------------------------------------------------------------------------
   Agent state
--------------------------------------------------------------------------- */

export function deriveAgentState(args: {
  snapshot: OnboardingSnapshot | null;
  progress: SignalsProgress;
  hasAnySignal: boolean;
  hasAnyTiny: boolean;
}): AgentState {
  const { snapshot, progress, hasAnySignal, hasAnyTiny } = args;

  const onboardingDone = Boolean(snapshot?.name || snapshot?.zip || snapshot?.situation);

  if (!onboardingDone && !hasAnySignal) return "EMPTY";
  if (onboardingDone && !hasAnySignal) return "WELCOME";

  const allDone = progress.motivationsDone && progress.strengthsDone && progress.skillsDone;
  if (allDone) return hasAnyTiny ? "RETURNING" : "ACTIVE";

  return "FOUNDATION";
}

/* ---------------------------------------------------------------------------
   Canonical justification lines
--------------------------------------------------------------------------- */

function strengthsJustification() {
  return "Motivations tells me why you move. Strengths tells me how you move — day-to-day — so the options I suggest actually match how you operate.";
}

function motivationsStartLine() {
  return "If you want one smart place to begin, we’ll start with Motivations — it tells me what genuinely gives you energy (and what drains you), so the next steps feel like you.";
}

/* ---------------------------------------------------------------------------
   Public API: buildRetort (pure)
--------------------------------------------------------------------------- */

export function buildRetort(args: {
  agentState: AgentState;
  nextKey: SignalKey;
  progress: SignalsProgress;
  snapshot: OnboardingSnapshot | null;
  answers: StoryAnswers | null;
  homeState: string | null;
  weeklyFocus: WeeklyFocusState | null;
  sprintCount: number;
  sprintDoneThisSession: boolean;
}): RetortViewModel {
  const {
    agentState,
    nextKey,
    progress,
    snapshot,
    answers,
    homeState,
    weeklyFocus,
    sprintCount,
    sprintDoneThisSession,
  } = args;

  const rawLower = buildRawText(snapshot, answers);

  const stateOnce = homeState ? `Starting from ${homeState}, ` : "";

  const totalAnswered =
    progress.motivationsAnswered + progress.strengthsAnswered + progress.skillsAnswered;

  const motivationsCaptured = progress.motivationsDone;
  const strengthsNext = nextKey === "strengths" && !progress.strengthsDone;

  /* -----------------------------------------------------------------------
     EMPTY
  ----------------------------------------------------------------------- */
  if (agentState === "EMPTY") {
    return {
      key: "empty",
      paragraphs: [
        "Welcome to Everleap.",
        "We’ll take this one step at a time. I’m not here to test you or push you into a path — I’m here to listen, notice patterns, and help you make sense of options without the noise.",
        "If you’re up for it, we’ll start with Motivations.",
      ],
    };
  }

  /* -----------------------------------------------------------------------
     WELCOME
  ----------------------------------------------------------------------- */
  if (agentState === "WELCOME") {
    const reflection = synthesizeMotivationReflection({ snapshot, answers });
    const stage = stageLine(snapshot, rawLower);
    const opener = `${stateOnce}${stage ? `${stage} ` : ""}${reflection.patternLine}`.trim();

    return {
      key: "welcome",
      paragraphs: [
        opener,
        reflection.evidenceLine ? safeOneSentence(reflection.evidenceLine) : "",
        motivationsStartLine(),
      ].filter(Boolean),
    };
  }

  /* -----------------------------------------------------------------------
     FOUNDATION → Strengths (special deterministic justification)
  ----------------------------------------------------------------------- */
  if (strengthsNext && motivationsCaptured) {
    const reflection: Reflection = synthesizeMotivationReflection({ snapshot, answers });
    const stage = stageLine(snapshot, rawLower);

    return {
      key: "foundation_strengths",
      paragraphs: [
        `${stateOnce}${stage ? `${stage} ` : ""}${reflection.patternLine}`.trim(),
        reflection.evidenceLine ? safeOneSentence(reflection.evidenceLine) : "",
        strengthsJustification(),
      ].filter(Boolean),
    };
  }

  /* -----------------------------------------------------------------------
     Default / Active / Returning
  ----------------------------------------------------------------------- */
  const reflection = synthesizeMotivationReflection({ snapshot, answers });
  const stage = stageLine(snapshot, rawLower);

  const p1 = `${stateOnce}${stage ? `${stage} ` : ""}${reflection.patternLine}`.trim();
  const p2 = reflection.evidenceLine ? safeOneSentence(reflection.evidenceLine) : "";

  let p3 =
    totalAnswered > 0
      ? "You’ve already given me enough to stop guessing — now we make it practical. One step at a time."
      : "We’ll keep this lightweight and useful. One step at a time.";

  if (sprintDoneThisSession && sprintCount > 0) {
    p3 = `${p3} (And nice — you already logged a sprint.)`;
  }

  const hasFocus = Boolean(weeklyFocus?.vibe && weeklyFocus?.target);
  if (hasFocus && agentState !== "WELCOME" && agentState !== "EMPTY") {
    p3 = `${p3} I’m also tracking a Weekly Focus — we can build from that anytime.`;
  }

  return {
    key: "default",
    paragraphs: [p1, p2, p3].filter(Boolean),
  };
}