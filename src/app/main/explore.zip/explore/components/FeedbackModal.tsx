// src/app/main/explore/components/FeedbackModal.tsx
"use client";

import * as React from "react";
import { X, Send, ThumbsUp, Minus, ThumbsDown } from "lucide-react";

import type { FeedbackResponse, RecommendationItem } from "../content/contracts";

/* ============================================================================
   Everleap Explore — FeedbackModal (mobile-first)
   - Bottom-sheet style on mobile
   - Captures response + optional comment
   - (Reasons are placeholder only; not wired into store yet)
============================================================================ */

type Props = {
  open: boolean;
  onClose: () => void;

  rec: RecommendationItem | null;
  response: FeedbackResponse | null;

  onSubmit: (payload: {
    response: FeedbackResponse;
    comment: string | null;
    reasons?: string[]; // placeholder (not used yet)
  }) => void;

  /** Phase 2+: show reason chips (kept off for now) */
  showReasons?: boolean;
};

const REASONS: Array<{ id: string; label: string }> = [
  { id: "too_expensive", label: "Too expensive" },
  { id: "too_time_intensive", label: "Too time-intensive" },
  { id: "too_risky", label: "Too risky" },
  { id: "not_me", label: "Not me" },
  { id: "already_doing_this", label: "Already doing this" },
  { id: "not_now", label: "Not now" },
  { id: "too_vague", label: "Too vague" },
  { id: "too_corporate", label: "Too corporate" },
  { id: "too_social", label: "Too social" },
  { id: "too_solo", label: "Too solo" },
  { id: "other", label: "Other" },
];

function titleFor(response: FeedbackResponse | null) {
  if (response === "agree") return "Agree";
  if (response === "mixed") return "Mixed";
  if (response === "disagree") return "Disagree";
  return "Feedback";
}

function iconFor(response: FeedbackResponse | null) {
  if (response === "agree") return <ThumbsUp className="h-4 w-4" />;
  if (response === "mixed") return <Minus className="h-4 w-4" />;
  if (response === "disagree") return <ThumbsDown className="h-4 w-4" />;
  return null;
}

export default function FeedbackModal({
  open,
  onClose,
  rec,
  response,
  onSubmit,
  showReasons = false,
}: Props) {
  const [comment, setComment] = React.useState("");
  const [selectedReasons, setSelectedReasons] = React.useState<string[]>([]);

  React.useEffect(() => {
    if (!open) return;
    setComment("");
    setSelectedReasons([]);
  }, [open]);

  React.useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const rTitle = titleFor(response);
  const canSubmit = Boolean(response) && Boolean(rec);

  function toggleReason(id: string) {
    setSelectedReasons((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }

  function submit() {
    if (!response || !rec) return;
    const trimmed = comment.trim();

    onSubmit({
      response,
      comment: trimmed.length ? trimmed : null,
      reasons: showReasons ? selectedReasons : undefined,
    });
  }

  return (
    <div className="fixed inset-0 z-[100]">
      {/* Backdrop */}
      <button
        type="button"
        aria-label="Close feedback"
        onClick={onClose}
        className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"
      />

      {/* Sheet */}
      <div className="absolute inset-x-0 bottom-0 mx-auto w-full max-w-3xl">
        <div className="rounded-t-[28px] border border-white/10 bg-slate-950/85 shadow-2xl backdrop-blur-xl">
          {/* Handle */}
          <div className="flex justify-center pt-3">
            <div className="h-1.5 w-12 rounded-full bg-white/20" />
          </div>

          {/* Header */}
          <div className="flex items-start justify-between gap-3 px-5 pb-3 pt-4 sm:px-7">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-white/10 text-white">
                  {iconFor(response)}
                </span>
                <div className="text-base font-semibold text-white">
                  {rTitle}
                </div>
              </div>

              <div className="mt-2 text-sm text-white/75">
                {rec ? (
                  <>
                    About:{" "}
                    <span className="font-semibold text-white">{rec.title}</span>
                  </>
                ) : (
                  "Share a quick reaction."
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white hover:bg-white/10 active:scale-95"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Body */}
          <div className="px-5 pb-5 sm:px-7">
            {showReasons ? (
              <div className="mb-4">
                <div className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-white/55">
                  Why this reaction?
                </div>
                <div className="flex flex-wrap gap-2">
                  {REASONS.map((r) => {
                    const active = selectedReasons.includes(r.id);
                    return (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => toggleReason(r.id)}
                        className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition active:scale-95 ${
                          active
                            ? "border-white/20 bg-white/15 text-white"
                            : "border-white/10 bg-white/5 text-white/80 hover:bg-white/10"
                        }`}
                      >
                        {r.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : null}

            <div className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-white/55">
              Add a comment (optional)
            </div>

            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={
                response === "disagree"
                  ? "Tell Everleap what feels off (tone, fit, assumptions)…"
                  : response === "mixed"
                    ? "What part fits, and what doesn’t?"
                    : "What makes this feel right?"
              }
              rows={4}
              className="w-full resize-none rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/35 focus:outline-none focus:ring-2 focus:ring-white/15"
            />

            {/* Footer */}
            <div className="mt-4 flex items-center justify-between gap-3">
              <div className="text-xs text-white/45">
                You can change your mind later.
              </div>

              <button
                type="button"
                onClick={submit}
                disabled={!canSubmit}
                className={`inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold shadow-lg transition active:scale-95 ${
                  canSubmit
                    ? "bg-white text-slate-950 hover:bg-white/90"
                    : "cursor-not-allowed bg-white/15 text-white/55"
                }`}
              >
                Send <Send className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="h-2" />
      </div>
    </div>
  );
}
