// src/app/main/explore/state/feedbackStore.ts
"use client";

import type {
  ExploreBatch,
  ExploreBatchStatus,
  FeedbackResponse,
  FeedbackTargetType,
  RankingState,
  RecommendationItem,
  UserBeliefFeedback,
} from "../content/contracts";

import {
  applyFeedbackToRankingState,
  createInitialRankingState,
  rerankRecommendations,
} from "../content/ranking";

import { DEFAULT_EXPLORE_FEEDBACK_CONFIG } from "../content/contracts";

/* ============================================================================
   Everleap Explore — Feedback Store
   - Slot-stable “top 4” behavior (visibleRecIds)
   - NEW: localStorage persistence (so refresh doesn’t wipe feedback)
============================================================================ */

const PERSIST_KEY = "everleap.explore.feedback.v1";

/** Simple ID generator that works in modern browsers. */
function makeId(prefix: string): string {
  const uuid =
    typeof globalThis !== "undefined" &&
    "crypto" in globalThis &&
    typeof globalThis.crypto.randomUUID === "function"
      ? globalThis.crypto.randomUUID()
      : `${Date.now()}_${Math.random().toString(16).slice(2)}`;
  return `${prefix}_${uuid}`;
}

function nowIso(): string {
  return new Date().toISOString();
}

/** Internal: store state */
type ExploreFeedbackStoreState = {
  batch: ExploreBatch | null;

  /**
   * The current 4 visible slots in order.
   * Each entry is a recId (or null if we can’t fill a slot).
   */
  visibleRecIds: Array<string | null>;

  ranking: RankingState;
};

let _state: ExploreFeedbackStoreState = {
  batch: null,
  visibleRecIds: new Array(DEFAULT_EXPLORE_FEEDBACK_CONFIG.visibleCount).fill(
    null
  ),
  ranking: createInitialRankingState(),
};

type Listener = (state: ExploreFeedbackStoreState) => void;
const _listeners = new Set<Listener>();

/* ============================================================================
   Persistence (localStorage)
============================================================================ */

type PersistedState = {
  version: 1;
  savedAt: string;
  state: ExploreFeedbackStoreState;
};

let _hydrated = false;
let _saveTimer: number | null = null;

function canUseStorage(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof window.localStorage !== "undefined"
  );
}

function safeParse(json: string): unknown {
  try {
    return JSON.parse(json);
  } catch {
    return null;
  }
}

function hydrateOnce(): void {
  if (_hydrated) return;
  _hydrated = true;

  if (!canUseStorage()) return;

  const raw = window.localStorage.getItem(PERSIST_KEY);
  if (!raw) return;

  const parsed = safeParse(raw) as PersistedState | null;
  if (!parsed || parsed.version !== 1) return;

  const incoming = parsed.state;

  // Very light validation so we don’t brick the UI on partial data
  if (!incoming || typeof incoming !== "object") return;

  _state = {
    batch: incoming.batch ?? null,
    visibleRecIds:
      incoming.visibleRecIds ??
      new Array(DEFAULT_EXPLORE_FEEDBACK_CONFIG.visibleCount).fill(null),
    ranking: incoming.ranking ?? createInitialRankingState(),
  };
}

function scheduleSave(): void {
  if (!canUseStorage()) return;

  // Debounce saves (avoid spamming localStorage during rapid UI events)
  if (_saveTimer) window.clearTimeout(_saveTimer);

  _saveTimer = window.setTimeout(() => {
    _saveTimer = null;

    const payload: PersistedState = {
      version: 1,
      savedAt: nowIso(),
      state: _state,
    };

    try {
      window.localStorage.setItem(PERSIST_KEY, JSON.stringify(payload));
    } catch {
      // If storage is full or blocked, ignore (client-only convenience)
    }
  }, 200);
}

function emit() {
  scheduleSave();
  for (const l of _listeners) l(_state);
}

/* ============================================================================
   Public: subscribe / get
============================================================================ */

export function subscribeExploreFeedbackStore(listener: Listener): () => void {
  hydrateOnce();
  _listeners.add(listener);
  listener(_state);
  return () => _listeners.delete(listener);
}

export function getExploreFeedbackState(): ExploreFeedbackStoreState {
  hydrateOnce();
  return _state;
}

/* ============================================================================
   Helpers
============================================================================ */

function getAllRecommendations(): RecommendationItem[] {
  return _state.batch?.recommendations ?? [];
}

function getRecById(recId: string): RecommendationItem | null {
  const recs = getAllRecommendations();
  return recs.find((r) => r.recId === recId) ?? null;
}

function getRerankedAll(): RecommendationItem[] {
  return rerankRecommendations(getAllRecommendations(), _state.ranking);
}

/**
 * Candidates are:
 * - not currently visible
 * - not already shown
 * - not dismissed (avoid resurfacing dislikes)
 */
function getCandidatePool(): RecommendationItem[] {
  const batch = _state.batch;
  if (!batch) return [];

  const visible = new Set(_state.visibleRecIds.filter(Boolean) as string[]);
  const shown = new Set(batch.shownRecIds);
  const dismissed = new Set(batch.dismissedRecIds);

  return getRerankedAll().filter((r) => {
    if (visible.has(r.recId)) return false;
    if (shown.has(r.recId)) return false;
    if (dismissed.has(r.recId)) return false;
    return true;
  });
}

function ensureShown(recId: string) {
  const batch = _state.batch;
  if (!batch) return;

  if (batch.shownRecIds.includes(recId)) return;

  _state = {
    ..._state,
    batch: {
      ...batch,
      shownRecIds: [...batch.shownRecIds, recId],
    },
  };
}

/** Fill any empty slots up to visibleCount using best candidates. */
function fillEmptySlots(): void {
  const batch = _state.batch;
  if (!batch) return;

  const visibleCount = DEFAULT_EXPLORE_FEEDBACK_CONFIG.visibleCount;
  const nextVisible = _state.visibleRecIds.slice(0, visibleCount);

  let pool = getCandidatePool();

  for (let i = 0; i < visibleCount; i++) {
    if (nextVisible[i]) continue;
    const next = pool.shift();
    if (!next) break;

    nextVisible[i] = next.recId;
    ensureShown(next.recId);

    // Keep correctness (pool depends on visible ids)
    pool = getCandidatePool();
  }

  _state = {
    ..._state,
    visibleRecIds: nextVisible,
  };
}

/** Replace a specific slot with the next best candidate (or null if none). */
function replaceSlot(slotIndex: number): void {
  const batch = _state.batch;
  if (!batch) return;

  const visibleCount = DEFAULT_EXPLORE_FEEDBACK_CONFIG.visibleCount;
  if (slotIndex < 0 || slotIndex >= visibleCount) return;

  const nextVisible = _state.visibleRecIds.slice(0, visibleCount);
  nextVisible[slotIndex] = null;

  _state = {
    ..._state,
    visibleRecIds: nextVisible,
  };

  fillEmptySlots();
}

/** Update batch status to exhausted if we can’t keep 4 visible options. */
function updateExhaustionStatus(): void {
  const batch = _state.batch;
  if (!batch) return;

  const visibleCount = DEFAULT_EXPLORE_FEEDBACK_CONFIG.visibleCount;
  const filled = _state.visibleRecIds
    .slice(0, visibleCount)
    .filter(Boolean).length;

  const poolSize = getCandidatePool().length;

  const exhausted = filled < visibleCount && poolSize === 0;

  const nextStatus: ExploreBatchStatus =
    exhausted && batch.status === "active" ? "exhausted" : batch.status;

  if (nextStatus !== batch.status) {
    _state = {
      ..._state,
      batch: {
        ...batch,
        status: nextStatus,
      },
    };
  }
}

/* ============================================================================
   Public: create/init
============================================================================ */

/** Build a minimal batch shape from a list of recs (e.g., placeholder content). */
export function createExploreBatchFromRecommendations(
  recommendations: RecommendationItem[],
  generationRunId?: string
): ExploreBatch {
  const runId =
    generationRunId ?? recommendations[0]?.generationRunId ?? makeId("run");
  const now = nowIso();

  const normalized: RecommendationItem[] = recommendations.map((r) => ({
    ...r,
    generationRunId: runId,
    generatedAt: r.generatedAt ?? now,
  }));

  return {
    generationRunId: runId,
    createdAt: now,
    recommendations: normalized,
    shownRecIds: [],
    dismissedRecIds: [],
    savedRecIds: [],
    feedbackEvents: [],
    status: "active",
  };
}

export function initializeExploreFeedbackStore(batch: ExploreBatch) {
  hydrateOnce();

  // If we already have a batch (e.g., restored from localStorage), do not overwrite it.
  // This preserves user feedback across refreshes.
  if (_state.batch) {
    // Still ensure slots are filled (in case content changed)
    fillEmptySlots();
    updateExhaustionStatus();
    emit();
    return;
  }

  _state = {
    batch,
    visibleRecIds: new Array(DEFAULT_EXPLORE_FEEDBACK_CONFIG.visibleCount).fill(
      null
    ),
    ranking: createInitialRankingState(),
  };

  fillEmptySlots();
  updateExhaustionStatus();
  emit();
}

/* ============================================================================
   Public: selectors
============================================================================ */

export function getVisibleRecommendations(): RecommendationItem[] {
  const visibleCount = DEFAULT_EXPLORE_FEEDBACK_CONFIG.visibleCount;

  const recs: RecommendationItem[] = [];
  for (const id of _state.visibleRecIds.slice(0, visibleCount)) {
    if (!id) continue;
    const rec = getRecById(id);
    if (rec) recs.push(rec);
  }
  return recs;
}

/** Compatibility: returns current visible slot recs and ensures slots are filled. */
export function getAndMarkVisibleRecommendations(): RecommendationItem[] {
  hydrateOnce();
  fillEmptySlots();
  updateExhaustionStatus();
  return getVisibleRecommendations();
}

export function getDisagreeCount(): number {
  return _state.batch?.dismissedRecIds.length ?? 0;
}

export function shouldSuggestRecalibrate(): boolean {
  const batch = _state.batch;
  if (!batch) return false;
  if (batch.status !== "active") return false;

  return (
    getDisagreeCount() >=
    DEFAULT_EXPLORE_FEEDBACK_CONFIG.suggestRecalibrateAfterDisagrees
  );
}

/* ============================================================================
   Public: mutations
============================================================================ */

type RecordFeedbackArgs = {
  targetType?: FeedbackTargetType; // default "recommendation"
  targetId?: string; // default derived from rec
  rec: RecommendationItem;
  response: FeedbackResponse;
  comment?: string | null;
  reasons?: UserBeliefFeedback["reasons"];
};

export function recordFeedback(
  args: RecordFeedbackArgs
): UserBeliefFeedback | null {
  hydrateOnce();

  const batch = _state.batch;
  if (!batch) return null;

  const targetType: FeedbackTargetType = args.targetType ?? "recommendation";
  const targetId =
    args.targetId ??
    (targetType === "recommendation" ? args.rec.recId : args.rec.claimId);

  const feedback: UserBeliefFeedback = {
    feedbackId: makeId("fb"),
    generationRunId: batch.generationRunId,
    targetType,
    targetId,
    response: args.response,
    comment: args.comment ?? null,
    reasons: args.reasons,
    createdAt: nowIso(),
    visibility: "private",
  };

  const nextRanking = applyFeedbackToRankingState(
    _state.ranking,
    feedback,
    args.rec
  );

  const dismissed = new Set(batch.dismissedRecIds);
  const saved = new Set(batch.savedRecIds);

  if (args.response === "disagree") dismissed.add(args.rec.recId);
  if (args.response === "agree") saved.add(args.rec.recId);

  const nextBatch: ExploreBatch = {
    ...batch,
    feedbackEvents: [...batch.feedbackEvents, feedback],
    dismissedRecIds: Array.from(dismissed),
    savedRecIds: Array.from(saved),
  };

  _state = {
    ..._state,
    batch: nextBatch,
    ranking: nextRanking,
  };

  const idx = _state.visibleRecIds.findIndex((id) => id === args.rec.recId);
  if (idx >= 0) replaceSlot(idx);
  else fillEmptySlots();

  updateExhaustionStatus();
  emit();
  return feedback;
}

/**
 * UI calls this when the user presses “Recalibrate Suggestions”.
 * For now: flips batch state + timestamps; later: trigger server job.
 */
export function requestRecalibration(): void {
  hydrateOnce();

  const batch = _state.batch;
  if (!batch) return;

  if (batch.status !== "active" && batch.status !== "exhausted") return;

  _state = {
    ..._state,
    batch: {
      ...batch,
      status: "recalibrating",
      recalibrationRequestedAt: nowIso(),
    },
  };
  emit();
}

/**
 * Optional: if/when a new batch arrives, you can supersede the old one.
 */
export function supersedeWithNewBatch(newBatch: ExploreBatch): void {
  hydrateOnce();

  _state = {
    batch: newBatch,
    visibleRecIds: new Array(DEFAULT_EXPLORE_FEEDBACK_CONFIG.visibleCount).fill(
      null
    ),
    ranking: createInitialRankingState(),
  };

  fillEmptySlots();
  updateExhaustionStatus();
  emit();
}

/**
 * Optional utility: clear local persisted feedback for Explore (dev/testing).
 * Not used by UI yet.
 */
export function clearExploreFeedbackPersistence(): void {
  if (!canUseStorage()) return;
  try {
    window.localStorage.removeItem(PERSIST_KEY);
  } catch {
    // ignore
  }
}
