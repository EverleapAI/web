// src/app/main/explore/page.tsx
"use client";

import * as React from "react";

import { BottomNav } from "@/components/navigation/BottomNav";
import { AppChrome } from "@/components/site/AppChrome";

import {
  isDarkTheme,
  type SpotlightThemeId,
  type GradientLevel,
} from "@/theme/everleapVisuals";

import type {
  ExploreKey,
  ExploreSection,
  ExploreChip,
  ExploreChipType,
} from "./content/types";
import { EXPLORE_SECTIONS } from "./content";
import { RENDERERS } from "./renderers";

/* ========= helpers ========= */

function displayLabelForSection(s: ExploreSection): string {
  if (s.key === ("forYou" as ExploreKey)) return "Careers";
  return s.label;
}

function isRecommendationsLane(key: ExploreKey): boolean {
  return (
    key === ("recommendations" as ExploreKey) || key === ("forYou" as ExploreKey)
  );
}

/* ========= Explore tab config ========= */

type TabMeta = {
  dot: string;
  subtitle: string;
};

function metaForSectionKey(key: ExploreKey): TabMeta {
  switch (key as string) {
    case "recommendations":
    case "forYou":
      return { dot: "bg-sky-400", subtitle: "Everleap suggestions" };
    case "education":
      return { dot: "bg-amber-400", subtitle: "School + learning paths" };
    case "travel":
      return { dot: "bg-emerald-400", subtitle: "Places + adventures" };
    case "community":
      return { dot: "bg-violet-400", subtitle: "People + belonging" };
    case "hobbies":
      return { dot: "bg-rose-400", subtitle: "Fun to explore" };
    default:
      return { dot: "bg-slate-300", subtitle: "Browse ideas" };
  }
}

/* ========= scroll helper ========= */

function useCompactTabs(thresholdPx = 56): boolean {
  const [compact, setCompact] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === "undefined") return;

    const onScroll = () => {
      const y = window.scrollY || 0;
      setCompact(y > thresholdPx);
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [thresholdPx]);

  return compact;
}

export default function ExplorePage() {
  const [themeId, setThemeId] = React.useState<SpotlightThemeId>("nightDusk");
  const [gradientLevel, setGradientLevel] = React.useState<GradientLevel>(3);
  const dark = isDarkTheme(themeId);

  const sections: ExploreSection[] = EXPLORE_SECTIONS as ExploreSection[];

  const [activeKey, setActiveKey] = React.useState<ExploreKey>(() => {
    return (sections[0]?.key ?? "education") as ExploreKey;
  });

  const activeIndex = sections.findIndex((s) => s.key === activeKey);
  const activeSection = sections[activeIndex] ?? sections[0];

  const renderRecommendationsLane = isRecommendationsLane(activeSection.key);

  const recChip: ExploreChip | null = React.useMemo(() => {
    if (!renderRecommendationsLane) return null;
    const chips = activeSection.chips ?? [];
    return (
      chips.find((c) => (c.type as string) === "recommendations") ?? chips[0]
    );
  }, [activeSection, renderRecommendationsLane]);

  const compactTabs = useCompactTabs(64);

  const tabWrapShell = dark
    ? "border-white/10 bg-slate-950/50"
    : "border-black/10 bg-white/90";

  return (
    <AppChrome
      themeId={themeId}
      gradientLevel={gradientLevel}
      onThemeChange={setThemeId}
      onGradientChange={setGradientLevel}
    >
      <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-4">
        {/* Header */}
        <div className="mb-3">
          <h1
            className={`text-lg font-semibold ${
              dark ? "text-white" : "text-slate-900"
            }`}
          >
            Explore
          </h1>
          <p className={`text-sm ${dark ? "text-white/70" : "text-slate-600"}`}>
            Everleap suggestions — directions that fit your strengths, values, and
            vibe.
          </p>
        </div>

        {/* Carousel Tabs */}
        <div className="sticky top-2 z-40 -mx-4 px-4">
          <div
            className={`relative overflow-hidden rounded-3xl border shadow-sm backdrop-blur-xl ${tabWrapShell}`}
          >
            <div className="pointer-events-none absolute inset-0">
              <div className="absolute -top-12 -left-14 h-44 w-44 rounded-full bg-gradient-to-br from-sky-500/20 via-cyan-400/12 to-indigo-500/10 blur-3xl opacity-70" />
              <div className="absolute -bottom-14 -right-10 h-48 w-48 rounded-full bg-gradient-to-br from-violet-500/18 via-fuchsia-400/10 to-sky-500/10 blur-3xl opacity-55" />
            </div>

            <div
              className={`relative flex snap-x snap-mandatory overflow-x-auto no-scrollbar ${
                compactTabs ? "p-2 gap-2" : "p-3 gap-3"
              }`}
            >
              {sections.map((s) => {
                const active = s.key === activeKey;
                const label = displayLabelForSection(s);
                const meta = metaForSectionKey(s.key);

                return (
                  <button
                    key={s.key}
                    onClick={() => setActiveKey(s.key)}
                    className={`snap-center shrink-0 transition select-none ${
                      compactTabs
                        ? "rounded-full px-3 py-2"
                        : "rounded-3xl px-4 py-3"
                    } ${
                      active
                        ? dark
                          ? "bg-white/15 text-white"
                          : "bg-slate-900 text-white"
                        : dark
                        ? "text-white/85 hover:bg-white/10"
                        : "text-slate-800 hover:bg-slate-100"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={`h-2.5 w-2.5 rounded-full ${
                          active ? meta.dot : `${meta.dot} opacity-70`
                        }`}
                      />
                      <div
                        className={`font-semibold ${
                          compactTabs ? "text-xs" : "text-sm"
                        }`}
                      >
                        {label}
                      </div>
                    </div>

                    {!compactTabs && (
                      <div className="mt-1 text-[0.75rem] leading-4 opacity-70">
                        {meta.subtitle}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Lane */}
        <div
          className={`mt-4 rounded-3xl border p-4 shadow-sm ${
            dark ? "border-white/10 bg-white/5" : "border-black/10 bg-white"
          }`}
        >
          <div className="mb-3">
            <h2
              className={`text-base font-semibold ${
                dark ? "text-white" : "text-slate-900"
              }`}
            >
              {renderRecommendationsLane ? "Careers" : activeSection.title}
            </h2>
            <p className={`text-sm ${dark ? "text-white/70" : "text-slate-600"}`}>
              {renderRecommendationsLane
                ? "Everleap suggestions — directions that fit your strengths, values, and vibe."
                : activeSection.subtitle}
            </p>
          </div>

          {renderRecommendationsLane ? (
            recChip ? (
              (() => {
                const Renderer = RENDERERS[recChip.type as ExploreChipType];
                return <Renderer key={recChip.id} chip={recChip} dark={dark} />;
              })()
            ) : (
              <div>No recommendations yet.</div>
            )
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {activeSection.chips.map((chip) => {
                const Renderer = RENDERERS[chip.type as ExploreChipType];
                return <Renderer key={chip.id} chip={chip} dark={dark} />;
              })}
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </AppChrome>
  );
}
