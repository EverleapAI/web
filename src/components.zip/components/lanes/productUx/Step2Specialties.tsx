// src/components/lanes/productUx/Step2Specialties.tsx
"use client";

import * as React from "react";
import { CheckCircle2, Gamepad2, HeartPulse, GraduationCap, Trophy, ShoppingBag } from "lucide-react";
import type { StepCommonProps } from "@/components/lanes/StepperShell";

type Specialty = {
  id: string;
  label: string;
  blurb: string;
  icon: React.ReactNode;
};

const MAX_PICK = 3;

const SPECIALTIES: Specialty[] = [
  {
    id: "health",
    label: "Health + wellness",
    blurb: "Apps that help people feel better, heal, or stay consistent.",
    icon: <HeartPulse className="h-4 w-4" />,
  },
  {
    id: "games",
    label: "Games + entertainment",
    blurb: "Fun experiences, rewards, progression, community, play.",
    icon: <Gamepad2 className="h-4 w-4" />,
  },
  {
    id: "education",
    label: "Education",
    blurb: "Learning flows, motivation, habits, and student tools.",
    icon: <GraduationCap className="h-4 w-4" />,
  },
  {
    id: "sports",
    label: "Sports + performance",
    blurb: "Training, coaching, feedback loops, and measurable progress.",
    icon: <Trophy className="h-4 w-4" />,
  },
  {
    id: "commerce",
    label: "Commerce + creators",
    blurb: "Shops, marketplaces, subscriptions, and audience tools.",
    icon: <ShoppingBag className="h-4 w-4" />,
  },
];

export default function Step2Specialties(props: StepCommonProps) {
  const { dark, accentClass, progress, setProgress, openGuide, laneId } = props;

  const picks = progress.selectedSpecialtyIds ?? [];
  const [pulse, setPulse] = React.useState(false);

  const micro = dark ? "text-slate-300/70" : "text-slate-600/70";
  const body = dark ? "text-slate-200/90" : "text-slate-800";

  const surface = dark ? "border-white/10 bg-slate-950/35" : "border-slate-200 bg-white/85";
  const chip = dark ? "border-white/10 bg-white/5 text-slate-100" : "border-slate-200 bg-white text-slate-800";

  function togglePick(id: string) {
    const on = picks.includes(id);

    if (on) {
      setProgress({
        selectedSpecialtyIds: picks.filter((x) => x !== id),
      });
      return;
    }

    if (picks.length >= MAX_PICK) {
      // tiny “nope” feedback (mobile friendly)
      setPulse(true);
      window.setTimeout(() => setPulse(false), 260);

      openGuide?.({
        source: "lane_specialties_limit",
        lane: { id: laneId, title: "Product / UX" },
        prompt:
          "User hit the specialties max. Ask ONE question to help them pick the best 3 specialties for them, then confirm the final 3.",
      });
      return;
    }

    setProgress({
      selectedSpecialtyIds: [...picks, id],
    });
  }

  function clearAll() {
    setProgress({ selectedSpecialtyIds: [] });
  }

  return (
    <div className="space-y-4">
      {/* Header card */}
      <div className={`rounded-3xl border p-4 ${surface}`}>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className={`text-[0.7rem] font-semibold uppercase tracking-[0.22em] ${micro}`}>Specialties</div>
            <div className={`mt-1 text-base font-semibold ${dark ? "text-slate-50" : "text-slate-900"}`}>
              Pick 1–3 areas so Everleap can tailor the deep dive.
            </div>
            <div className={`mt-1 text-sm ${body}`}>
              This doesn’t lock you in — it just makes the next screens feel more “you.”
            </div>
          </div>

          <div className="shrink-0 text-right">
            <div
              className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold ${chip} ${
                pulse ? "scale-[1.03]" : ""
              } transition`}
              title="Max 3 picks"
            >
              <span
                className={`inline-flex h-2 w-2 rounded-full bg-gradient-to-b ${accentClass}`}
                aria-hidden
              />
              {picks.length}/{MAX_PICK}
            </div>

            {picks.length ? (
              <button
                type="button"
                onClick={clearAll}
                className={`mt-2 text-[0.75rem] font-semibold ${
                  dark ? "text-slate-200/70 hover:text-slate-50" : "text-slate-700/70 hover:text-slate-900"
                }`}
              >
                Clear
              </button>
            ) : null}
          </div>
        </div>
      </div>

      {/* Grid (mobile friendly: single column; two column on wider) */}
      <div className="grid gap-3 sm:grid-cols-2">
        {SPECIALTIES.map((s) => {
          const on = picks.includes(s.id);

          return (
            <button
              key={s.id}
              type="button"
              onClick={() => togglePick(s.id)}
              className={`group relative w-full overflow-hidden rounded-3xl border p-4 text-left transition active:scale-[0.99] ${
                on
                  ? dark
                    ? "border-sky-300/50 bg-slate-950/40 shadow-[0_0_55px_rgba(56,189,248,0.18)]"
                    : "border-sky-300 bg-white shadow-[0_0_55px_rgba(56,189,248,0.14)]"
                  : surface
              }`}
              aria-pressed={on}
              aria-label={`${on ? "Selected" : "Not selected"}: ${s.label}`}
            >
              {/* tiny accent wash */}
              <div className="pointer-events-none absolute inset-0">
                <div
                  className={`absolute -top-10 -left-10 h-44 w-44 rounded-full blur-3xl opacity-20 bg-gradient-to-br ${accentClass}`}
                />
              </div>

              <div className="relative flex items-start gap-3">
                <div
                  className={`inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border ${
                    on ? (dark ? "border-sky-300/60 bg-sky-300/10 text-sky-100" : "border-sky-300 bg-sky-50 text-sky-700") : chip
                  }`}
                  aria-hidden
                >
                  {s.icon}
                </div>

                <div className="min-w-0">
                  <div className={`flex items-center justify-between gap-2`}>
                    <div className={`text-sm font-semibold ${dark ? "text-slate-50" : "text-slate-900"}`}>
                      {s.label}
                    </div>

                    {on ? (
                      <span
                        className={`inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[0.7rem] font-semibold ${
                          dark ? "border-sky-300/50 bg-sky-300/10 text-sky-100" : "border-sky-300 bg-sky-50 text-sky-700"
                        }`}
                      >
                        <CheckCircle2 className="h-3 w-3" />
                        Picked
                      </span>
                    ) : null}
                  </div>

                  <div className={`mt-1 text-sm ${body}`}>{s.blurb}</div>

                  <div className={`mt-3 text-[0.72rem] font-semibold ${micro}`}>
                    Tap to {on ? "unselect" : "select"}
                  </div>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Subtle guidance */}
      <div className={`rounded-3xl border p-4 ${surface}`}>
        <div className={`text-xs font-semibold uppercase tracking-[0.18em] ${micro}`}>Tip</div>
        <div className={`mt-2 text-sm ${body}`}>
          If you’re unsure, pick the ones that make you think:{" "}
          <span className={dark ? "text-slate-50 font-semibold" : "text-slate-900 font-semibold"}>
            “I’d actually try that this week.”
          </span>
        </div>
      </div>
    </div>
  );
}
