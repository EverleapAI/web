"use client";

import * as React from "react";
import type {
  StepperStep,
  StepperPersistedState,
} from "@/components/career/stepperTypes";

type Props = {
  step: StepperStep;
  progress: StepperPersistedState;
};

function normalizeZip(v: unknown): string {
  const s = typeof v === "string" ? v.trim() : "";
  if (/^\d{5}(-\d{4})?$/.test(s)) return s;
  return "";
}

type Pulse = "yes" | "maybe" | "no";

function copyForPulse(p: Pulse | null) {
  if (p === "yes") {
    return {
      title: "That’s a good sign.",
      body: "Next we’ll pick your **specialty vibe** so this stops being a concept and starts being *you*.",
    };
  }
  if (p === "maybe") {
    return {
      title: "Perfect. “Maybe” is real.",
      body: "We’ll keep it low-pressure. One tiny step at a time — and if it feels wrong, we pivot fast.",
    };
  }
  if (p === "no") {
    return {
      title: "Honestly? That’s useful.",
      body: "You just saved yourself time. You can exit anytime and try a different direction — that’s the whole point.",
    };
  }
  return null;
}

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-white/10 bg-slate-950/40 px-3 py-1.5 text-xs text-slate-100">
      {children}
    </span>
  );
}

function ChoiceCard({
  title,
  body,
  chips,
}: {
  title: string;
  body: string;
  chips: string[];
}) {
  return (
    <div className="rounded-3xl border border-white/10 bg-slate-950/40 p-5 shadow-[0_18px_60px_rgba(0,0,0,0.55)] backdrop-blur-xl">
      <div className="text-sm font-semibold text-slate-50">{title}</div>
      <div className="mt-2 text-sm leading-relaxed text-slate-200/85">{body}</div>
      <div className="mt-3 flex flex-wrap gap-2">
        {chips.map((c) => (
          <Chip key={c}>{c}</Chip>
        ))}
      </div>
    </div>
  );
}

export function OverviewStep({ step, progress }: Props) {
  // Some environments have zipCode typed as {} — treat as unknown and normalize.
  const zip = normalizeZip((progress as unknown as { zipCode?: unknown }).zipCode);

  const [pulse, setPulse] = React.useState<Pulse | null>(null);
  const pulseCopy = copyForPulse(pulse);

  return (
    <section className="mx-auto w-full max-w-3xl space-y-4">
      {/* Step label (short + human) */}
      <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[0.7rem] font-semibold uppercase tracking-[0.22em] text-white/70">
        Dive deeper · {step.title}
      </div>

      {/* Hero: story-first, not list-first */}
      <div className="rounded-[28px] border border-white/10 bg-gradient-to-br from-sky-400/15 via-fuchsia-400/8 to-amber-300/10 p-[1px]">
        <div className="rounded-[27px] bg-slate-950/55 p-5 backdrop-blur-2xl">
          <h1 className="text-3xl font-semibold tracking-tight text-slate-50">Product / UX</h1>

          <p className="mt-2 text-sm leading-relaxed text-slate-200/90">
            Imagine this: your friend (or your mom) opens an app and says{" "}
            <span className="text-slate-50 font-semibold">“Why is this so confusing?”</span>{" "}
            You’re the person who quietly goes,{" "}
            <span className="text-slate-50 font-semibold">“I can fix that.”</span>
          </p>

          <p className="mt-2 text-sm leading-relaxed text-slate-200/85">
            Product/UX is basically: make confusing things feel obvious — and then test if it actually worked.
          </p>

          <div className="mt-4 flex flex-wrap gap-2">
            <Chip>Make it clearer</Chip>
            <Chip>Test with real humans</Chip>
            <Chip>Improve fast</Chip>
            <Chip>Small wins → momentum</Chip>
          </div>
        </div>
      </div>

      {/* Quick gut-check (more teen voice) */}
      <div className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur-xl">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="text-sm font-semibold text-slate-50">Quick gut-check</div>
            <div className="mt-1 text-sm text-slate-200/85">
              When you picture doing this… does it feel kind of{" "}
              <span className="text-slate-50 font-semibold">exciting</span>?
            </div>
            <div className="mt-2 text-xs text-slate-300/60">
              No wrong answer. This is just you collecting signal.
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setPulse((p) => (p === "yes" ? null : "yes"))}
              className={`inline-flex items-center gap-2 rounded-full border px-3.5 py-2 text-sm font-semibold transition active:scale-95 ${
                pulse === "yes"
                  ? "border-sky-200/25 bg-sky-300/20 text-sky-50"
                  : "border-white/10 bg-slate-950/30 text-slate-100 hover:bg-white/10"
              }`}
            >
              ✅ Yep
            </button>

            <button
              type="button"
              onClick={() => setPulse((p) => (p === "maybe" ? null : "maybe"))}
              className={`inline-flex items-center gap-2 rounded-full border px-3.5 py-2 text-sm font-semibold transition active:scale-95 ${
                pulse === "maybe"
                  ? "border-amber-200/25 bg-amber-300/18 text-amber-50"
                  : "border-white/10 bg-slate-950/30 text-slate-100 hover:bg-white/10"
              }`}
            >
              🙂 Maybe
            </button>

            <button
              type="button"
              onClick={() => setPulse((p) => (p === "no" ? null : "no"))}
              className={`inline-flex items-center gap-2 rounded-full border px-3.5 py-2 text-sm font-semibold transition active:scale-95 ${
                pulse === "no"
                  ? "border-rose-200/25 bg-rose-300/18 text-rose-50"
                  : "border-white/10 bg-slate-950/30 text-slate-100 hover:bg-white/10"
              }`}
            >
              👎 Nope
            </button>
          </div>
        </div>

        {pulseCopy ? (
          <div className="mt-4 rounded-2xl border border-white/10 bg-slate-950/35 px-4 py-3">
            <div className="text-sm font-semibold text-slate-50">{pulseCopy.title}</div>
            <div className="mt-1 text-sm text-slate-200/85">{pulseCopy.body}</div>
          </div>
        ) : null}
      </div>

      {/* Make it feel like a “choose your vibe” story, not a report */}
      <div className="grid gap-3">
        <ChoiceCard
          title="What this feels like (on a good day)"
          body="You notice something is weird/confusing, you redesign it, and people go: “Ohhh… that’s way better.” It’s the feeling of making life smoother."
          chips={["clarity", "tiny experiments", "real reactions"]}
        />

        <ChoiceCard
          title="What you’ll actually do"
          body="You’ll make flows and screens easier: onboarding, checkout, dashboards, settings… You’ll test ideas with people and keep improving until it works."
          chips={["prototype", "test", "iterate"]}
        />

        {/* Micro-test (narrative + punchy) */}
        <div className="rounded-3xl border border-white/10 bg-slate-950/40 p-5 shadow-[0_18px_60px_rgba(0,0,0,0.55)] backdrop-blur-xl">
          <div className="text-sm font-semibold text-slate-50">A 3-day challenge (low stakes)</div>
          <div className="mt-2 text-sm text-slate-200/85">
            Not “commit to a career.” Just run an experiment and see how your brain reacts.
          </div>

          <div className="mt-4 space-y-2">
            {[
              { n: 1, t: "Pick one annoying screen you use a lot." },
              { n: 2, t: "Redesign it fast (paper is fine). Make it clearer." },
              { n: 3, t: "Show 2 people. Ask: “Better… or still confusing?”" },
            ].map((x) => (
              <div
                key={x.n}
                className="flex items-start gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
              >
                <span className="mt-0.5 inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-sky-300 text-xs font-bold text-slate-950">
                  {x.n}
                </span>
                <div className="text-sm text-slate-100">{x.t}</div>
              </div>
            ))}
          </div>

          <div className="mt-4 rounded-2xl border border-white/10 bg-slate-950/35 px-4 py-3 text-xs text-slate-200/80">
            <span className="font-semibold text-slate-50">Reality check:</span>{" "}
            The goal isn’t “pretty.” The goal is “people instantly know what to do.”
          </div>
        </div>
      </div>

      {/* Point forward (Specialties) */}
      <div className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur-xl">
        <div className="text-sm font-semibold text-slate-50">Next up: Specialties</div>
        <div className="mt-2 text-sm leading-relaxed text-slate-200/85">
          Product/UX has different “flavors” (apps, healthcare, games, AI, etc.). Next screen: you’ll pick the ones that
          feel most like <span className="text-slate-50 font-semibold">your vibe</span>.
        </div>
      </div>

      {/* Tiny footer hint */}
      <div className="pt-1 text-xs text-slate-300/60">
        {zip ? (
          <>
            Later we can tailor local options around <span className="text-slate-100">{zip}</span>.
          </>
        ) : (
          <>Later we’ll ask for your ZIP so we can show local options.</>
        )}
      </div>
    </section>
  );
}
