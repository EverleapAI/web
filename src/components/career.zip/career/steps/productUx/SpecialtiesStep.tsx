"use client";

import * as React from "react";
import type {
  StepperStep,
  StepperPersistedState,
} from "@/components/career/stepperTypes";

type Props = {
  step: StepperStep;
  progress: StepperPersistedState;
  setProgress: React.Dispatch<React.SetStateAction<StepperPersistedState>>;
};

type Specialty = {
  id: string;
  title: string;
  blurb: string;
  examples: string[];
  bestFor: string;
};

const SPECIALTIES: Specialty[] = [
  {
    id: "consumerApps",
    title: "Consumer apps",
    blurb: "High-velocity products where clarity + delight matter. Strong taste + fast iteration.",
    examples: ["Social", "Music", "Photo/video", "Fitness", "Shopping"],
    bestFor: "If you love making things feel effortless.",
  },
  {
    id: "healthcare",
    title: "Healthcare / medical UX",
    blurb: "Complex systems with real consequences. Safety, trust, and accessibility are everything.",
    examples: ["Patient portals", "Telehealth", "Clinician tools", "Wearables"],
    bestFor: "If meaning + impact is non-negotiable.",
  },
  {
    id: "education",
    title: "Education products",
    blurb: "Learning design + motivation design. You build for attention, confidence, and progress.",
    examples: ["Study tools", "Tutoring platforms", "School systems", "Language learning"],
    bestFor: "If you like coaching people through change.",
  },
  {
    id: "games",
    title: "Games / interactive experiences",
    blurb: "Flow state, feedback loops, and emotional design. UX is the product.",
    examples: ["Mobile games", "Game UX/UI", "Live ops", "Player journeys"],
    bestFor: "If you’re obsessed with engagement and feeling.",
  },
  {
    id: "fintech",
    title: "Fintech",
    blurb: "Money is emotional. You design for trust, risk, and clean decision-making.",
    examples: ["Banking", "Investing", "Payments", "Budgeting"],
    bestFor: "If you like clarity under pressure.",
  },
  {
    id: "enterprise",
    title: "Enterprise / B2B tools",
    blurb: "Power-user workflows. Less flashy, more “make hard jobs easier.”",
    examples: ["Dashboards", "Admin tools", "Workflow systems", "Analytics"],
    bestFor: "If you like systems thinking and reducing chaos.",
  },
  {
    id: "aiProducts",
    title: "AI product UX",
    blurb: "Explainability + trust + good defaults. You design human + model collaboration.",
    examples: ["Copilots", "Chat UX", "AI editors", "Safety UX"],
    bestFor: "If you like building the future (and making it understandable).",
  },
  {
    id: "accessibility",
    title: "Accessibility & inclusive design",
    blurb: "Designing so more humans can succeed. This multiplies impact across every product.",
    examples: ["WCAG", "Neurodiversity", "Assistive tech", "Plain language"],
    bestFor: "If you want your work to help the widest set of people.",
  },
];

const PICK_KEY = "productUx_specialties";

/** Read-only helpers (no `any`) */
function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function readStringArray(v: unknown): string[] {
  if (!Array.isArray(v)) return [];
  if (!v.every((x) => typeof x === "string")) return [];
  return v;
}

/**
 * PersistedState doesn’t guarantee a “bag” key.
 * We support common keys: data | progress | meta.
 * If none exist, we create/use `data`.
 */
function getBag(
  p: StepperPersistedState
): { key: "data" | "progress" | "meta"; bag: Record<string, unknown> } {
  const root = p as unknown as Record<string, unknown>;

  const d = root["data"];
  if (isRecord(d)) return { key: "data", bag: d };

  const pr = root["progress"];
  if (isRecord(pr)) return { key: "progress", bag: pr };

  const m = root["meta"];
  if (isRecord(m)) return { key: "meta", bag: m };

  return { key: "data", bag: {} };
}

function setBag(
  p: StepperPersistedState,
  key: "data" | "progress" | "meta",
  bag: Record<string, unknown>
) {
  // we purposely write the bag back into the same key (or `data` if none existed)
  return {
    ...(p as unknown as Record<string, unknown>),
    [key]: bag,
    updatedAt: new Date().toISOString(),
  } as StepperPersistedState;
}

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-white/10 bg-slate-950/40 px-3 py-1.5 text-xs text-slate-100">
      {children}
    </span>
  );
}

function accentFor(id: string) {
  // Light heuristic palette to make the list feel alive.
  // (No new dependencies; Tailwind-only.)
  if (id === "consumerApps") return "from-sky-300/25 via-cyan-300/12 to-indigo-300/12";
  if (id === "healthcare") return "from-emerald-300/22 via-teal-300/12 to-sky-300/10";
  if (id === "education") return "from-amber-300/22 via-orange-300/12 to-rose-300/10";
  if (id === "games") return "from-violet-300/22 via-fuchsia-300/12 to-sky-300/10";
  if (id === "fintech") return "from-lime-300/18 via-emerald-300/10 to-teal-300/10";
  if (id === "enterprise") return "from-slate-300/16 via-slate-200/8 to-sky-300/10";
  if (id === "aiProducts") return "from-fuchsia-300/20 via-violet-300/12 to-sky-300/10";
  if (id === "accessibility") return "from-rose-300/18 via-amber-300/10 to-lime-300/10";
  return "from-sky-300/20 via-cyan-300/10 to-indigo-300/10";
}

export function SpecialtiesStep({ step, progress, setProgress }: Props) {
  const { key: bagKey, bag } = getBag(progress);

  const picked = readStringArray(bag[PICK_KEY]);
  const pickedSet = React.useMemo(() => new Set(picked), [picked]);

  function toggle(id: string) {
    const next = pickedSet.has(id)
      ? picked.filter((x) => x !== id)
      : [...picked, id].slice(-3);

    setProgress((prev) => {
      const { key, bag: prevBag } = getBag(prev);
      const nextBag: Record<string, unknown> = { ...prevBag, [PICK_KEY]: next };
      return setBag(prev, key, nextBag);
    });
  }

  const coachLine = React.useMemo(() => {
    if (!picked.length) return "Pick up to 3 — just the ones that spark curiosity. This isn’t a commitment.";
    if (picked.length === 1) return "Nice. Add one more so we can triangulate your vibe.";
    if (picked.length === 2) return "Good signal. A third choice makes the next steps sharper.";
    return "Perfect. These three are enough to guide what shows up next.";
  }, [picked.length]);

  const pickedTitles = React.useMemo(() => {
    return picked
      .map((id) => SPECIALTIES.find((s) => s.id === id)?.title)
      .filter((x): x is string => Boolean(x));
  }, [picked]);

  const summaryLine = React.useMemo(() => {
    if (!pickedTitles.length) return "No wrong answers — we’re just finding your flavor.";
    if (pickedTitles.length === 1) return `So far you’re leaning: ${pickedTitles[0]}.`;
    if (pickedTitles.length === 2) return `You’re leaning: ${pickedTitles[0]} + ${pickedTitles[1]}.`;
    return `Your top 3: ${pickedTitles[0]}, ${pickedTitles[1]}, ${pickedTitles[2]}.`;
  }, [pickedTitles]);

  return (
    <section className="mx-auto w-full max-w-3xl space-y-4">
      <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[0.7rem] font-semibold uppercase tracking-[0.22em] text-white/70">
        Dive deeper · {step.title}
      </div>

      <div className="space-y-2">
        <h1 className="text-3xl font-semibold tracking-tight text-slate-50">
          Pick a specialty vibe
        </h1>
        <p className="text-sm leading-relaxed text-slate-200/85">
          Product/UX is a big umbrella. This is how we stop it from feeling vague:
          choose the kinds of people + problems you want to design for.
        </p>
      </div>

      {/* Coach card */}
      <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-slate-950/40 p-5 shadow-[0_18px_60px_rgba(0,0,0,0.55)] backdrop-blur-xl">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -top-12 -left-12 h-48 w-48 rounded-full bg-gradient-to-br from-sky-500/18 via-cyan-400/10 to-indigo-500/10 blur-3xl opacity-70" />
          <div className="absolute -bottom-16 -right-12 h-56 w-56 rounded-full bg-gradient-to-br from-violet-500/14 via-fuchsia-400/8 to-sky-500/10 blur-3xl opacity-60" />
        </div>

        <div className="relative">
          <div className="flex items-center justify-between gap-3">
            <div className="text-sm font-semibold text-slate-50">
              Coach note
            </div>
            <div className="text-xs text-slate-300/60">
              {picked.length}/3 picked
              <span className="ml-2 opacity-60">({bagKey})</span>
            </div>
          </div>

          <p className="mt-2 text-sm text-slate-200/85">{coachLine}</p>

          <div className="mt-2 text-xs text-slate-300/70">{summaryLine}</div>

          {picked.length ? (
            <div className="mt-3 flex flex-wrap gap-2">
              {picked.map((id) => {
                const s = SPECIALTIES.find((x) => x.id === id);
                if (!s) return null;
                return <Chip key={id}>{s.title}</Chip>;
              })}
            </div>
          ) : null}
        </div>
      </div>

      {/* Options */}
      <div className="space-y-3">
        {SPECIALTIES.map((s) => {
          const on = pickedSet.has(s.id);
          const accent = accentFor(s.id);

          return (
            <button
              key={s.id}
              type="button"
              onClick={() => toggle(s.id)}
              className={`
                relative w-full text-left transition active:scale-[0.99]
                rounded-[28px] border p-[1px] backdrop-blur-xl
                ${on ? "border-sky-300/55" : "border-white/10"}
              `}
              aria-pressed={on}
              aria-label={`Toggle ${s.title}`}
            >
              <div className={`pointer-events-none absolute inset-0 rounded-[28px] bg-gradient-to-br ${accent} opacity-60`} />
              <div
                className={`
                  relative rounded-[27px] p-5 shadow-[0_18px_60px_rgba(0,0,0,0.55)]
                  ${on ? "bg-slate-950/62" : "bg-slate-950/42 hover:bg-slate-950/50"}
                `}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <div className="text-base font-semibold text-slate-50">
                        {s.title}
                      </div>

                      {on ? (
                        <span className="inline-flex items-center rounded-full border border-sky-200/25 bg-sky-300/15 px-2 py-0.5 text-[0.7rem] font-semibold text-sky-100">
                          Selected
                        </span>
                      ) : null}
                    </div>

                    <div className="mt-2 text-sm leading-relaxed text-slate-200/85">
                      {s.blurb}
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      {s.examples.slice(0, 4).map((e) => (
                        <Chip key={e}>{e}</Chip>
                      ))}
                    </div>

                    <div className="mt-3 text-xs text-slate-300/70">
                      <span className="font-semibold text-slate-100">
                        Best for:
                      </span>{" "}
                      {s.bestFor}
                    </div>
                  </div>

                  <div
                    className={`mt-1 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-xs font-bold ${
                      on
                        ? "border-sky-300/60 bg-sky-300/18 text-sky-100"
                        : "border-white/10 bg-white/5 text-white/70"
                    }`}
                    aria-hidden
                  >
                    {on ? "✓" : "+"}
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between gap-3 text-xs text-slate-300/60">
                  <span>
                    Tap to {on ? "remove" : "pick"} · (max 3)
                  </span>
                  {on ? <span className="text-sky-200/80">Locked in</span> : null}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
