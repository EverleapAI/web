// front-end/src/app/api/me/route.ts
export const dynamic = "force-dynamic";
export const revalidate = 0;
export const runtime = "nodejs";

import { NextRequest, NextResponse } from "next/server";

/**
 * Lightweight session hydration proxy.
 * Forwards cookies to the API and returns the current user/session payload.
 *
 * Backend target (computed from NEXT_PUBLIC_API_BASE_URL):
 *   GET {API_BASE}/me
 */

const RAW_BASE = (process.env.NEXT_PUBLIC_API_BASE_URL || "").replace(/\/+$/, "");
if (!RAW_BASE) throw new Error("Missing NEXT_PUBLIC_API_BASE_URL for /api/me proxy.");
const API_BASE = /\/api$/i.test(RAW_BASE) ? RAW_BASE : `${RAW_BASE}/api`;
const TARGET_URL = `${API_BASE}/me`;

function noStore(res: NextResponse) {
  res.headers.set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  res.headers.set("Pragma", "no-cache");
  res.headers.set("Vary", "Cookie");
  return res;
}

export async function GET(req: NextRequest) {
  const host = req.headers.get("x-forwarded-host") || req.headers.get("host") || "";
  const proto = req.headers.get("x-forwarded-proto") || "https";

  const upstream = await fetch(TARGET_URL, {
    method: "GET",
    headers: {
      cookie: req.headers.get("cookie") || "",
      "x-forwarded-host": host,
      "x-forwarded-proto": proto,
      "user-agent": req.headers.get("user-agent") || "",
      "cache-control": "no-cache",
    },
    redirect: "manual",
    cache: "no-store",
  });

  const contentType = upstream.headers.get("content-type") || "application/json; charset=utf-8";
  const isJson = contentType.includes("application/json");
  const body = isJson ? await upstream.json().catch(() => ({})) : await upstream.text();

  const res = new NextResponse(
    typeof body === "string" ? body : JSON.stringify(body ?? {}),
    { status: upstream.status, headers: { "content-type": contentType } }
  );

  // If backend refreshes session or rotates cookie, forward Set-Cookie as-is (no Domain pinning).
  const setCookie = upstream.headers.get("set-cookie");
  if (setCookie) res.headers.append("set-cookie", setCookie);

  return noStore(res);
}
