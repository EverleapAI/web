"use client";

import * as React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

import { BottomNav } from "@/components/navigation/BottomNav";
import { AppChrome } from "@/components/site/AppChrome";

import {
  isDarkTheme,
  type SpotlightThemeId,
  type GradientLevel,
} from "@/theme/everleapVisuals";

import type {
  ExploreKey,
  ExploreSection,
  ExploreChip,
  ExploreChipType,
} from "./content/types";
import { EXPLORE_SECTIONS } from "./content";
import { RENDERERS } from "./renderers";

/* ========= helpers ========= */

function displayLabelForSection(s: ExploreSection): string {
  if (s.key === ("forYou" as ExploreKey)) return "Careers";
  return s.label;
}

function isRecommendationsLane(key: ExploreKey): boolean {
  return (
    key === ("recommendations" as ExploreKey) || key === ("forYou" as ExploreKey)
  );
}

/* ========= Explore tab config ========= */

type TabMeta = {
  dot: string;
  subtitle: string;
  badgeIcon: string; // emoji badge
  badgeHalo: string; // gradient halo for badge
  badgeText: string; // text color for emoji
};

function metaForSectionKey(key: ExploreKey): TabMeta {
  switch (key as string) {
    case "recommendations":
    case "forYou":
      return {
        dot: "bg-sky-400",
        subtitle: "Everleap suggestions",
        badgeIcon: "🧭",
        badgeHalo: "from-sky-500/35 via-cyan-400/20 to-indigo-500/20",
        badgeText: "text-sky-50",
      };
    case "education":
      return {
        dot: "bg-amber-400",
        subtitle: "School + learning paths",
        badgeIcon: "🎓",
        badgeHalo: "from-amber-500/35 via-orange-400/18 to-rose-400/18",
        badgeText: "text-amber-50",
      };
    case "travel":
      return {
        dot: "bg-emerald-400",
        subtitle: "Places + adventures",
        badgeIcon: "🌍",
        badgeHalo: "from-emerald-500/35 via-teal-400/18 to-sky-400/18",
        badgeText: "text-emerald-50",
      };
    case "community":
      return {
        dot: "bg-violet-400",
        subtitle: "People + belonging",
        badgeIcon: "🤝",
        badgeHalo: "from-violet-500/35 via-fuchsia-400/18 to-sky-400/18",
        badgeText: "text-violet-50",
      };
    case "hobbies":
      return {
        dot: "bg-rose-400",
        subtitle: "Fun to explore",
        badgeIcon: "🎨",
        badgeHalo: "from-rose-500/35 via-pink-400/18 to-amber-400/18",
        badgeText: "text-rose-50",
      };
    default:
      return {
        dot: "bg-slate-300",
        subtitle: "Browse ideas",
        badgeIcon: "✨",
        badgeHalo: "from-slate-500/25 via-slate-400/15 to-slate-300/15",
        badgeText: "text-slate-50",
      };
  }
}

/* ========= scroll helper (big tabs -> compact pills) ========= */

function useCompactTabs(thresholdPx = 56): boolean {
  const [compact, setCompact] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === "undefined") return;

    const onScroll = () => {
      const y = window.scrollY || 0;
      setCompact(y > thresholdPx);
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [thresholdPx]);

  return compact;
}

export default function ExplorePage() {
  const [themeId, setThemeId] = React.useState<SpotlightThemeId>("nightDusk");
  const [gradientLevel, setGradientLevel] = React.useState<GradientLevel>(3);
  const dark = isDarkTheme(themeId);

  const sections: ExploreSection[] = EXPLORE_SECTIONS as ExploreSection[];

  const [activeKey, setActiveKey] = React.useState<ExploreKey>(() => {
    const first = sections[0]?.key;
    return (first ?? "education") as ExploreKey;
  });

  const activeIndex = React.useMemo(() => {
    const idx = sections.findIndex((s) => s.key === activeKey);
    return idx === -1 ? 0 : idx;
  }, [activeKey, sections]);

  const activeSection: ExploreSection = sections[activeIndex] ?? sections[0];

  const renderRecommendationsLane = isRecommendationsLane(activeSection.key);

  const recChip: ExploreChip | null = React.useMemo(() => {
    if (!renderRecommendationsLane) return null;
    const chips = activeSection.chips ?? [];
    if (chips.length === 0) return null;

    const preferred =
      chips.find((c) => (c.type as string) === "recommendations") ?? chips[0];

    return preferred;
  }, [activeSection.chips, renderRecommendationsLane]);

  const pageTitle = "Explore";
  const pageSubtitle = "Let’s find what fits you.";

  const compactTabs = useCompactTabs(64);

  const tabWrapShell = dark
    ? "border-white/10 bg-slate-950/50"
    : "border-black/10 bg-white/90";

  // ===== tab strip refs + helpers =====
  const tabStripRef = React.useRef<HTMLDivElement | null>(null);
  const tabRefs = React.useRef<Record<string, HTMLButtonElement | null>>({});

  // Show arrows only when strip actually overflows
  const [canScroll, setCanScroll] = React.useState({ left: false, right: false });

  const updateCanScroll = React.useCallback(() => {
    const el = tabStripRef.current;
    if (!el) return;

    const left = el.scrollLeft > 2;
    const right = el.scrollLeft + el.clientWidth < el.scrollWidth - 2;
    setCanScroll({ left, right });
  }, []);

  React.useEffect(() => {
    updateCanScroll();

    const el = tabStripRef.current;
    if (!el) return;

    const onScroll = () => updateCanScroll();
    el.addEventListener("scroll", onScroll, { passive: true });

    const ro = new ResizeObserver(() => updateCanScroll());
    ro.observe(el);

    return () => {
      el.removeEventListener("scroll", onScroll);
      ro.disconnect();
    };
  }, [updateCanScroll]);

  // Keep active tab visible
  React.useEffect(() => {
    const btn = tabRefs.current[String(activeKey)];
    if (!btn) return;
    btn.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
  }, [activeKey]);

  function nudgeStrip(dir: "left" | "right") {
    const el = tabStripRef.current;
    if (!el) return;

    const amount = Math.max(220, Math.floor(el.clientWidth * 0.65));
    el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  }

  // Optional: map vertical wheel to horizontal scroll when hovering tabs
  function onStripWheel(e: React.WheelEvent<HTMLDivElement>) {
    const el = tabStripRef.current;
    if (!el) return;

    if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
    if (el.scrollWidth <= el.clientWidth + 2) return;

    e.preventDefault();
    el.scrollBy({ left: e.deltaY, behavior: "auto" });
  }

  // Lane header “pop”
  const laneMeta = metaForSectionKey(activeSection.key);
  const laneTitle = renderRecommendationsLane ? "Careers" : activeSection.title;
  const laneSubtitle = renderRecommendationsLane
    ? "Everleap recommendations — made for you."
    : activeSection.subtitle;

  const laneAccent = `bg-gradient-to-r ${laneMeta.badgeHalo}`;

  return (
    <AppChrome
      themeId={themeId}
      gradientLevel={gradientLevel}
      onThemeChange={setThemeId}
      onGradientChange={setGradientLevel}
    >
      <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-4">
        {/* Header */}
        <div className="mb-3 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1
              className={`text-lg font-semibold ${
                dark ? "text-white" : "text-slate-900"
              }`}
            >
              {pageTitle}
            </h1>
            <p className={`text-sm ${dark ? "text-white/70" : "text-slate-600"}`}>
              {pageSubtitle}
            </p>
          </div>
        </div>

        {/* Sticky section tabs (horizontal + desktop arrows) */}
        <div className="sticky top-2 z-40 -mx-4 px-4">
          <div
            className={`relative overflow-hidden rounded-3xl border shadow-sm backdrop-blur-xl ${tabWrapShell}`}
          >
            {/* subtle glow behind the tabs */}
            <div className="pointer-events-none absolute inset-0">
              <div className="absolute -top-12 -left-14 h-44 w-44 rounded-full bg-gradient-to-br from-sky-500/20 via-cyan-400/12 to-indigo-500/10 blur-3xl opacity-70" />
              <div className="absolute -bottom-14 -right-10 h-48 w-48 rounded-full bg-gradient-to-br from-violet-500/18 via-fuchsia-400/10 to-sky-500/10 blur-3xl opacity-55" />
            </div>

            {/* arrows + strip */}
            <div className={`relative ${compactTabs ? "p-2" : "p-3"}`}>
              {canScroll.left ? (
                <button
                  type="button"
                  onClick={() => nudgeStrip("left")}
                  className={`hidden sm:inline-flex absolute left-2 top-1/2 -translate-y-1/2 z-10 h-9 w-9 items-center justify-center rounded-full border shadow-sm transition active:scale-95 ${
                    dark
                      ? "border-white/10 bg-slate-950/50 text-white hover:bg-slate-950/70"
                      : "border-black/10 bg-white/90 text-slate-900 hover:bg-white"
                  }`}
                  aria-label="Scroll tabs left"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
              ) : null}

              {canScroll.right ? (
                <button
                  type="button"
                  onClick={() => nudgeStrip("right")}
                  className={`hidden sm:inline-flex absolute right-2 top-1/2 -translate-y-1/2 z-10 h-9 w-9 items-center justify-center rounded-full border shadow-sm transition active:scale-95 ${
                    dark
                      ? "border-white/10 bg-slate-950/50 text-white hover:bg-slate-950/70"
                      : "border-black/10 bg-white/90 text-slate-900 hover:bg-white"
                  }`}
                  aria-label="Scroll tabs right"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
              ) : null}

              <div
                ref={tabStripRef}
                onWheel={onStripWheel}
                className={`flex w-full gap-2 overflow-x-auto overscroll-x-contain scroll-smooth snap-x snap-mandatory
                  [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden
                  ${canScroll.left ? "sm:pl-11" : ""} ${canScroll.right ? "sm:pr-11" : ""}`}
              >
                {sections.map((s) => {
                  const active = s.key === activeKey;
                  const label = displayLabelForSection(s);
                  const meta = metaForSectionKey(s.key);

                  const base =
                    "group text-left transition active:scale-[0.99] select-none shrink-0 snap-start";

                  const shape = compactTabs
                    ? "rounded-full px-3 py-2"
                    : "rounded-3xl px-4 py-3";

                  const activeBg = active
                    ? dark
                      ? "bg-white/15 text-white"
                      : "bg-slate-900 text-white"
                    : dark
                    ? "text-white/85 hover:bg-white/10"
                    : "text-slate-800 hover:bg-slate-100";

                  const badgeSize = compactTabs
                    ? "h-7 w-7 rounded-2xl"
                    : "h-9 w-9 rounded-2xl";
                  const badgeText = compactTabs ? "text-sm" : "text-base";

                  return (
                    <button
                      key={s.key}
                      ref={(el) => {
                        tabRefs.current[String(s.key)] = el;
                      }}
                      type="button"
                      onClick={() => setActiveKey(s.key)}
                      className={`${base} ${shape} ${activeBg}`}
                    >
                      <div className="flex items-center gap-2">
                        {/* badge bubble */}
                        <span
                          className={`relative inline-flex ${badgeSize} items-center justify-center overflow-hidden border ${
                            dark ? "border-white/10" : "border-black/10"
                          }`}
                          aria-hidden
                        >
                          <span
                            className={`absolute inset-0 bg-gradient-to-br ${meta.badgeHalo}`}
                          />
                          <span className={`relative ${badgeText} ${meta.badgeText}`}>
                            {meta.badgeIcon}
                          </span>
                        </span>

                        <div className="min-w-0">
                          <div
                            className={`flex items-center gap-2 font-semibold ${
                              compactTabs ? "text-xs" : "text-sm"
                            }`}
                          >
                            <span
                              className={`h-2.5 w-2.5 rounded-full ${
                                active
                                  ? meta.dot
                                  : dark
                                  ? `${meta.dot} opacity-80`
                                  : `${meta.dot} opacity-70`
                              }`}
                              aria-hidden
                            />
                            <span className="truncate">{label}</span>
                          </div>

                          {!compactTabs ? (
                            <div
                              className={`mt-1 text-[0.75rem] leading-4 ${
                                active
                                  ? "text-white/70"
                                  : dark
                                  ? "text-white/55"
                                  : "text-slate-600"
                              }`}
                            >
                              {meta.subtitle}
                            </div>
                          ) : null}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {canScroll.right ? (
                <div className="pointer-events-none absolute right-0 top-0 h-full w-12">
                  <div
                    className={`h-full w-full ${
                      dark
                        ? "bg-gradient-to-l from-slate-950/55 to-transparent"
                        : "bg-gradient-to-l from-white/70 to-transparent"
                    }`}
                  />
                </div>
              ) : null}
            </div>
          </div>
        </div>

        {/* Lane card */}
        <div
          className={`mt-4 rounded-3xl border p-4 shadow-sm ${
            dark ? "border-white/10 bg-white/5" : "border-black/10 bg-white"
          }`}
        >
          {/* Lane “hero” header */}
          <div className="mb-3">
            <div className="min-w-0">
              <div className="flex items-center gap-3">
                {/* accent badge (slightly smaller + crisper) */}
                <div
                  className={`relative inline-flex h-9 w-9 items-center justify-center overflow-hidden rounded-2xl border ${
                    dark ? "border-white/10" : "border-black/10"
                  }`}
                  aria-hidden
                >
                  <div className={`absolute inset-0 ${laneAccent}`} />
                  <div className="relative text-[0.95rem] text-white">
                    {laneMeta.badgeIcon}
                  </div>
                </div>

                <div className="min-w-0">
                  <h2
                    className={`truncate text-lg font-semibold tracking-tight ${
                      dark ? "text-white" : "text-slate-900"
                    }`}
                  >
                    {laneTitle}
                  </h2>

                  <p
                    className={`text-sm ${
                      dark ? "text-white/70" : "text-slate-600"
                    }`}
                  >
                    {laneSubtitle}
                  </p>
                </div>
              </div>

              {/* crisper accent rule */}
              <div className="mt-3 h-[2px] w-28 overflow-hidden rounded-full">
                <div
                  className={`h-full w-full ${laneAccent} ${
                    dark ? "opacity-65" : "opacity-45"
                  }`}
                />
              </div>
            </div>
          </div>

          {renderRecommendationsLane ? (
            recChip ? (
              (() => {
                const Renderer = RENDERERS[recChip.type as ExploreChipType];
                return <Renderer key={recChip.id} chip={recChip} dark={dark} />;
              })()
            ) : (
              <div
                className={`rounded-2xl border p-5 ${
                  dark
                    ? "border-white/10 bg-white/5 text-white/80"
                    : "border-black/10 bg-white text-slate-700"
                }`}
              >
                No recommendations content found for this lane yet.
              </div>
            )
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {activeSection.chips.map((chip: ExploreChip) => {
                const Renderer = RENDERERS[chip.type as ExploreChipType];
                return <Renderer key={chip.id} chip={chip} dark={dark} />;
              })}
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </AppChrome>
  );
}
